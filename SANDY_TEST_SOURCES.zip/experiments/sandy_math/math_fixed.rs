pub struct AmountOut {
    pub amount_out: u64,
    pub new_reserve_a: u64,
    pub new_reserve_b: u64,
}

// k = y * x
fn get_amount_out(amount_in: u64, reserve_a: u64, reserve_b: u64) -> AmountOut {
    let amount_in_128 = u128::from(amount_in);
    let reserve_a_128 = u128::from(reserve_a);
    let reserve_b_128 = u128::from(reserve_b);

    let amount_in_after_fee = amount_in_128 * (10000 - 25) / 10000;

    let numerator = amount_in_after_fee * reserve_b_128;
    let denominator = reserve_a_128 + amount_in_after_fee;

    let amount_out = (numerator / denominator) as u64;

    AmountOut {
        amount_out,
        new_reserve_a: reserve_a + amount_in,
        new_reserve_b: reserve_b - amount_out,
    }
}

pub fn calculate_swap_amount_in(
    lb: u64,
    ub: u64,
    user_amount_in: u64,
    user_minimum_amount_out: u64,
    reserve_a: u64,
    reserve_b: u64,
) -> u64 {
    // Preserve the existing fee model. This repair only makes the search
    // bounded and rejects inputs that would overflow reserve accounting.
    if lb > ub || reserve_a == 0 || reserve_b == 0
        || reserve_a.checked_add(ub).and_then(|v| v.checked_add(user_amount_in)).is_none()
    {
        return 0;
    }
    let feasible = |amount| {
        let front = get_amount_out(amount, reserve_a, reserve_b);
        get_amount_out(user_amount_in, front.new_reserve_a, front.new_reserve_b).amount_out
            >= user_minimum_amount_out
    };
    if !feasible(lb) {
        return 0;
    }
    let mut low = lb;
    let mut high = ub;
    while low < high {
        let width = high - low;
        let mid = low + width / 2 + width % 2;
        if feasible(mid) {
            low = mid;
        } else {
            high = mid - 1;
        }
    }
    low
}
