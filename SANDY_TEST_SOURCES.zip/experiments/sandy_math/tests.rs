#[cfg(original)]
mod model { include!("math_original.rs"); }
#[cfg(not(original))]
mod model { include!("math_fixed.rs"); }

#[test]
fn regression_adjacent_interval() {
    assert_eq!(model::calculate_swap_amount_in(0, 1, 1, 0, 1000, 1000), 1);
}

#[test]
fn empty_interval() {
    assert_eq!(model::calculate_swap_amount_in(0, 0, 100, 0, 1000, 1000), 0);
}

#[test]
fn reversed_bounds_rejected() {
    assert_eq!(model::calculate_swap_amount_in(2, 1, 1, 0, 1000, 1000), 0);
}

#[test]
fn zero_liquidity_rejected() {
    assert_eq!(model::calculate_swap_amount_in(0, 10, 1, 0, 0, 1000), 0);
    assert_eq!(model::calculate_swap_amount_in(0, 10, 1, 0, 1000, 0), 0);
}

#[test]
fn reserve_overflow_rejected() {
    assert_eq!(model::calculate_swap_amount_in(0, u64::MAX, 1, 0, 1, 1000), 0);
}

#[test]
fn impossible_minimum_returns_zero() {
    assert_eq!(model::calculate_swap_amount_in(0, 10, 100, 1001, 1000, 1000), 0);
}

#[test]
fn maximum_valid_width_terminates() {
    assert_eq!(model::calculate_swap_amount_in(0, u64::MAX - 1, 0, 0, 1, 1000), u64::MAX - 1);
}

fn output(input: u64, a: u64, b: u64) -> u64 {
    let net = (input as u128) * 9975 / 10000;
    (net * (b as u128) / ((a as u128) + net)) as u64
}

#[test]
fn search_matches_exhaustive_enumeration() {
    // Independent exhaustive enumeration of the existing integer AMM model.
    // This verifies search behavior, not compatibility with a live pool.
    for a in [100u64, 1000, 10_000] {
        for b in [100u64, 1000, 10_000] {
            for user in [1u64, 10, 50] {
                let baseline = output(user, a, b);
                for minimum in [0, baseline / 2, baseline, baseline + 1] {
                    for upper in [1u64, 2, 5, 20, 100] {
                        let expected = (0..=upper).filter(|&front| {
                            let bought = output(front, a, b);
                            output(user, a + front, b - bought) >= minimum
                        }).max().unwrap_or(0);
                        assert_eq!(model::calculate_swap_amount_in(0, upper, user, minimum, a, b), expected,
                            "a={a} b={b} user={user} minimum={minimum} upper={upper}");
                    }
                }
            }
        }
    }
}
