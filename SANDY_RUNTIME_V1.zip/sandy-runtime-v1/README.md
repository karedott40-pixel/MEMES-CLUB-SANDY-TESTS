# Sandy — essais locaux d'achat et de revente

Ce paquet ajoute uniquement un banc d'essai au code Sandy déjà vérifié. Aucun mode réel n'est activé. Aucun portefeuille personnel n'est lu. Les clés des quatre acteurs et de la transaction intermédiaire contrôlée sont générées en mémoire, pour une chaîne locale neuve alimentée au démarrage avec des fonds fictifs.

Les programmes SBF Sandy et Raydium sont chargés dans la configuration initiale du réseau local ; aucune transaction de déploiement ni aucun appel à mainnet, devnet ou testnet public n'est effectué. Les essais s'exécutent dans un espace réseau Linux séparé ne contenant que l'interface locale `lo`, après téléchargement et compilation des outils. Ils ne peuvent donc pas atteindre un service externe.

Raydium : source officielle Apache-2.0 `raydium-io/raydium-amm`, version historique `d8e88250a648cff370d588acb91db7c4ff72b52b`, mode AMM v4 `SwapOnly`, avec réserves et comptes créés artificiellement à la genèse. Chaque fichier est vérifié contre son identifiant Git officiel. Ce n'est pas une copie certifiée du binaire actuellement déployé en production. Les comptes de carnet d'ordres ne sont pas actifs dans ce mode et ne sont pas couverts.

Contrôles prévus : entrée et sortie via de véritables instructions des programmes compilés ; frais confirmés et pourboire ; conservation des jetons antérieurs ; refus de dépassement du budget ; refus d'un autre signataire ; arrêt d'urgence ; échec d'une sortie après une entrée réussie ; annulation des échanges lorsqu'une transaction unique échoue ; cycle atomique entre wallets contrôlés ; rejet d'un devis de frais trop élevé avant signature.

La distinction entre transactions séparées et transaction unique est explicite : une transaction unique exige la signature des deux acteurs contrôlés et ne démontre pas l'atomicité d'un bundle Jito. Un scénario synthétique favorable ne démontre aucune rentabilité réelle. Un résultat attendu qui révèle une position bloquée est enregistré comme risque bloquant, pas comme permission d'utiliser des fonds.

Les comptes de test et les clés d'identité du validateur restent dans la machine GitHub jetable. Aucun cache ni publication de binaire ou de clé n'est configuré. Seuls les journaux d'essai et les résultats sans clés privées seront conservés après vérification.
