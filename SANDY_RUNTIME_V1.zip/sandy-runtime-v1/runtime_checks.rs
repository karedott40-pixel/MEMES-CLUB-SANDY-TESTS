//! Disposable CI harness. Only a new loopback validator, fictitious genesis funds,
//! and keys generated in memory. Not a bot transport and not a live trading mode.
extern crate solana_sdk as solana_program;
use anyhow::{anyhow,ensure,Context,Result};
use borsh::BorshDeserialize;
use serde_json::{json,Value};
use solana_client::{rpc_client::RpcClient,rpc_config::RpcSendTransactionConfig,rpc_request::RpcRequest};
use solana_sdk::{commitment_config::CommitmentConfig,compute_budget::ComputeBudgetInstruction,
    hash::Hash,instruction::{AccountMeta,Instruction},message::{Message,VersionedMessage},
    packet::PACKET_DATA_SIZE,pubkey,pubkey::Pubkey,rent::Rent,signature::Keypair,
    signer::Signer,system_program,transaction::{Transaction,VersionedTransaction}};
use std::{fs,net::{SocketAddr,TcpStream},path::{Path,PathBuf},process::{Child,Command,Stdio},
    sync::Arc,thread,time::{Duration,Instant}};
#[path="../config.rs"] mod config;
#[path="../ledger.rs"] mod ledger;
#[path="../decoder/mod.rs"] mod decoder;
#[path="../relayer.rs"] mod relayer;
#[path="../utils.rs"] mod utils;
#[path="../transaction.rs"] mod transaction;
#[path="../../../safety/core.rs"] mod guard;
#[path="../../../safety/protocol.rs"] mod protocol;
#[path="../../../program/src/state.rs"] mod state;

const RPC:&str="http://127.0.0.1:18899";
const SANDY:Pubkey=Pubkey::new_from_array([42;32]);
const TOKEN:Pubkey=pubkey!("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
const WSOL:Pubkey=pubkey!("So11111111111111111111111111111111111111112");
const DEX:Pubkey=pubkey!("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8");
const PRINCIPAL:u64=1_000_000_000;
const NETWORK_CAP:u64=200_000;
const TIP:u64=5_000;
const TARGET_INPUT:u64=100_000_000_000;
const PREVIOUS_TOKENS:u64=100_000_000;
const INITIAL_WSOL:u64=10_000_000_000;
const CANARY:&[u8]=b"MEMES_CLUB_FRESH_LOCAL_GENESIS_ONLY_20261103";

fn put64(data:&mut[u8],at:usize,value:u64){data[at..at+8].copy_from_slice(&value.to_le_bytes());}
fn putkey(data:&mut[u8],at:usize,key:Pubkey){data[at..at+32].copy_from_slice(key.as_ref());}
fn base64(data:&[u8])->String {
    const A:&[u8;64]=b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out=String::new();for c in data.chunks(3){let a=c[0];let b=*c.get(1).unwrap_or(&0);let d=*c.get(2).unwrap_or(&0);
        out.push(A[(a>>2)as usize]as char);out.push(A[(((a&3)<<4)|(b>>4))as usize]as char);
        out.push(if c.len()>1{A[(((b&15)<<2)|(d>>6))as usize]as char}else{'='});
        out.push(if c.len()>2{A[(d&63)as usize]as char}else{'='});}out
}
fn fixture(dir:&Path,key:Pubkey,owner:Pubkey,lamports:u64,data:Vec<u8>)->Result<()> {
    let value=json!({"pubkey":key.to_string(),"account":{"lamports":lamports,"data":[base64(&data),"base64"],
        "owner":owner.to_string(),"executable":false,"rentEpoch":0}});
    fs::write(dir.join(format!("{key}.json")),serde_json::to_vec(&value)?)?;Ok(())
}
fn token_fixture(dir:&Path,key:Pubkey,mint:Pubkey,owner:Pubkey,amount:u64)->Result<()> {
    let rent=Rent::default().minimum_balance(165);let mut d=vec![0;165];
    putkey(&mut d,0,mint);putkey(&mut d,32,owner);put64(&mut d,64,amount);d[108]=1;
    if mint==WSOL{d[109..113].copy_from_slice(&1u32.to_le_bytes());put64(&mut d,113,rent);}
    fixture(dir,key,TOKEN,rent+if mint==WSOL{amount}else{0},d)
}
struct Node(Child);impl Drop for Node{fn drop(&mut self){let _=self.0.kill();let _=self.0.wait();}}
struct Pool{amm:Pubkey,authority:Pubkey,coin_vault:Pubkey,pc_vault:Pubkey,mint:Pubkey,dummy:Pubkey,tip:Pubkey,canary:Pubkey}
impl Pool {
    fn create(dir:&Path,owners:&[Arc<Keypair>],victim:&Keypair)->Result<Self>{
        let (authority,bump)=Pubkey::find_program_address(&[b"amm authority"],&DEX);
        let p=Self{amm:Pubkey::new_unique(),authority,coin_vault:Pubkey::new_unique(),pc_vault:Pubkey::new_unique(),
            mint:Pubkey::new_unique(),dummy:Pubkey::new_unique(),tip:Pubkey::new_unique(),canary:Pubkey::new_unique()};
        let mut amm=vec![0;752];put64(&mut amm,0,6);put64(&mut amm,8,bump as u64); // SwapOnly: no order book.
        put64(&mut amm,16,7);put64(&mut amm,24,3);put64(&mut amm,32,9);put64(&mut amm,40,6);put64(&mut amm,120,1_000_000_000);
        for (at,n,d) in [(128,5,10_000),(144,25,10_000),(160,12,100),(176,25,10_000)]{put64(&mut amm,at,n);put64(&mut amm,at+8,d);}
        putkey(&mut amm,336,p.coin_vault);putkey(&mut amm,368,p.pc_vault);putkey(&mut amm,400,WSOL);putkey(&mut amm,432,p.mint);
        for at in [496,528,560,592]{putkey(&mut amm,at,p.dummy);}
        fixture(dir,p.amm,DEX,Rent::default().minimum_balance(752),amm)?;
        token_fixture(dir,p.coin_vault,WSOL,p.authority,1_000_000_000_000)?;
        token_fixture(dir,p.pc_vault,p.mint,p.authority,1_000_000_000_000)?;
        let mut mint=vec![0;82];put64(&mut mint,36,1_000_000_000_000+PREVIOUS_TOKENS*owners.len() as u64);mint[44]=6;mint[45]=1;
        fixture(dir,p.mint,TOKEN,Rent::default().minimum_balance(82),mint)?;
        for key in [p.authority,p.dummy,p.tip]{fixture(dir,key,system_program::id(),Rent::default().minimum_balance(0),vec![])?;}
        fixture(dir,p.canary,system_program::id(),Rent::default().minimum_balance(CANARY.len()),CANARY.to_vec())?;
        for key in owners.iter().map(|k|k.as_ref()).chain(std::iter::once(victim)){
            fixture(dir,key.pubkey(),system_program::id(),100_000_000_000,vec![])?;
            token_fixture(dir,utils::get_associated_token_address(&key.pubkey(),&WSOL),WSOL,key.pubkey(),
                if key.pubkey()==victim.pubkey(){500_000_000_000}else{INITIAL_WSOL})?;
            token_fixture(dir,utils::get_associated_token_address(&key.pubkey(),&p.mint),p.mint,key.pubkey(),
                if key.pubkey()==victim.pubkey(){0}else{PREVIOUS_TOKENS})?;
        }Ok(p)
    }
    fn route(&self,owner:Pubkey,back:bool)->[Pubkey;17]{
        let mut r=[self.dummy;17];r[0]=TOKEN;r[1]=self.amm;r[2]=self.authority;r[4]=self.coin_vault;r[5]=self.pc_vault;
        let w=utils::get_associated_token_address(&owner,&WSOL);let t=utils::get_associated_token_address(&owner,&self.mint);
        r[14]=if back{t}else{w};r[15]=if back{w}else{t};r[16]=owner;r
    }
    fn target_swap(&self,owner:Pubkey)->Instruction{
        let route=self.route(owner,false);let mut data=vec![9];data.extend(TARGET_INPUT.to_le_bytes());data.extend(1u64.to_le_bytes());
        Instruction{program_id:DEX,accounts:route.iter().enumerate().map(|(i,k)|
            if matches!(i,0|2|6|13|16){AccountMeta::new_readonly(*k,i==16)}else{AccountMeta::new(*k,false)}).collect(),data}
    }
}
struct Chain{client:RpcClient,genesis:Hash,last_hash:Option<Hash>,sequence:u32,transactions:Vec<Value>}
impl Chain {
    fn connect(pool:&Pool,node:&mut Node)->Result<Self>{
        let client=RpcClient::new_with_timeout_and_commitment(RPC.to_string(),Duration::from_secs(2),CommitmentConfig::confirmed());
        let until=Instant::now()+Duration::from_secs(90);loop{
            ensure!(node.0.try_wait()?.is_none(),"Local validator stopped before becoming healthy");
            if client.get_health().is_ok(){break;}ensure!(Instant::now()<until,"Local validator startup timeout");thread::sleep(Duration::from_millis(300));
        }
        ensure!(client.get_account_data(&pool.canary)?==CANARY,"Wrong local genesis marker");
        ensure!(client.get_account(&SANDY)?.executable && client.get_account(&DEX)?.executable,"Test programs absent");
        let genesis=client.get_genesis_hash()?;Ok(Self{client,genesis,last_hash:None,sequence:0,transactions:vec![]})
    }
    fn fresh_hash(&mut self)->Result<Hash>{
        let until=Instant::now()+Duration::from_secs(5);loop{let h=self.client.get_latest_blockhash()?;
            if Some(h)!=self.last_hash{self.last_hash=Some(h);return Ok(h);}ensure!(Instant::now()<until,"Blockhash did not advance");thread::sleep(Duration::from_millis(100));}
    }
    fn transaction(&mut self,ixs:Vec<Instruction>,payer:&Keypair,others:&[&Keypair],price:u64)->Result<VersionedTransaction>{
        self.sequence+=1;let mut all=vec![ComputeBudgetInstruction::set_compute_unit_limit(1_000_000+self.sequence),ComputeBudgetInstruction::set_compute_unit_price(price)];all.extend(ixs);
        let mut signers=vec![payer];signers.extend_from_slice(others);
        Ok(Transaction::new_signed_with_payer(&all,Some(&payer.pubkey()),&signers,self.fresh_hash()?).into())
    }
    fn submit(&mut self,label:&str,tx:&VersionedTransaction,success:bool,fee_cap:u64)->Result<Value>{
        ensure!(self.client.get_genesis_hash()?==self.genesis,"Local genesis changed");
        ensure!(bincode::serialize(tx)?.len()<=PACKET_DATA_SIZE,"Transaction exceeds Solana packet limit");
        let quoted=self.client.get_fee_for_message(&tx.message)?;ensure!(quoted>0 && quoted<=fee_cap,"Signed transaction fee exceeds reserved ceiling");
        let sig=self.client.send_transaction_with_config(tx,&RpcSendTransactionConfig{skip_preflight:true,max_retries:Some(0),..Default::default()})?;
        let until=Instant::now()+Duration::from_secs(25);let data:Value=loop{
            let v:Value=self.client.send(RpcRequest::GetTransaction,json!([sig.to_string(),{"encoding":"json","commitment":"confirmed","maxSupportedTransactionVersion":0}]))?;
            if !v.is_null(){break v;}ensure!(Instant::now()<until,"Transaction confirmation timeout: {label}");thread::sleep(Duration::from_millis(150));
        };
        let meta=&data["meta"];let actual=meta["fee"].as_u64().ok_or_else(||anyhow!("Missing confirmed fee"))?;
        let observed=meta["err"].is_null();let record=json!({"label":label,"signature":sig.to_string(),"slot":data["slot"],"success":observed,
            "error":meta["err"],"quoted_fee_lamports":quoted,"charged_fee_lamports":actual,"compute_units":meta["computeUnitsConsumed"],"logs":meta["logMessages"]});
        println!("CONFIRMED_LOCAL_TX={}",record);self.transactions.push(record.clone());
        ensure!(observed==success,"Unexpected transaction result: {label}: {}",meta["err"]);
        ensure!(quoted==actual,"Confirmed fee differs from quoted fee");Ok(record)
    }
    fn amount(&self,key:Pubkey)->Result<u64>{let d=self.client.get_account_data(&key)?;ensure!(d.len()==165,"Invalid token account size");Ok(u64::from_le_bytes(d[64..72].try_into()?))}
    fn state(&self,key:Pubkey)->Result<state::SandwichState>{Ok(state::SandwichState::try_from_slice(&self.client.get_account_data(&key)?)?)}
}
struct Case{key:Arc<Keypair>,config:config::Config,ledger:PathBuf,state:Pubkey}
impl Case{
    fn new(key:Arc<Keypair>,victim:Pubkey,p:&Pool,root:&Path,label:&str)->Self{
        let state=Pubkey::find_program_address(&[b"sandwich-state",key.pubkey().as_ref()],&SANDY).0;
        Self{config:config::Config{schema_version:2,mode:"inspect".into(),program_id:Some(SANDY.to_string()),payer_public_key:Some(key.pubkey().to_string()),
            rpc_url:RPC.into(),relay_url:"ws://127.0.0.1:18900".into(),allowed_pools:vec![p.amm.to_string()],allowed_target_wallets:vec![victim.to_string()],
            limits:config::LimitConfig{max_trade_lamports:PRINCIPAL,max_total_exposure_lamports:PRINCIPAL+NETWORK_CAP+TIP,max_network_fees_lamports:NETWORK_CAP,
                max_tip_lamports:TIP,max_account_cost_lamports:0,max_attempts:1}},key,ledger:root.join(format!("{label}-risk.json")),state}
    }
    fn request(&self,id:&str)->config::Request{config::Request{id:id.into(),pool:self.config.allowed_pools[0].clone(),target_wallet:self.config.allowed_target_wallets[0].clone(),
        total_principal_lamports:PRINCIPAL,total_network_fees_lamports:NETWORK_CAP,tip_lamports:TIP,account_cost_lamports:0}}
    fn initialize(&self,c:&mut Chain,p:&Pool,label:&str)->Result<Value>{
        let args=protocol::Initialize{limits:self.config.limits.limits(),tip_lamports:TIP,tip_receiver:p.tip.to_bytes(),minimum_profit_lamports:10_000};
        let ix=Instruction{program_id:SANDY,accounts:vec![AccountMeta::new(self.key.pubkey(),true),AccountMeta::new(self.state,false),AccountMeta::new_readonly(system_program::id(),false)],data:protocol::encode(0,&args)?};
        let before=c.client.get_balance(&self.key.pubkey())?;let tx=c.transaction(vec![ix],&self.key,&[],0)?;let record=c.submit(label,&tx,true,NETWORK_CAP)?;
        let after=c.client.get_balance(&self.key.pubkey())?;let rent=c.client.get_balance(&self.state)?;
        ensure!(before-after==record["charged_fee_lamports"].as_u64().unwrap()+rent,"Setup cost does not reconcile");
        let v=c.state(self.state)?;ensure!(v.authority==self.key.pubkey() && !v.active && v.budget.attempts==0,"Initial program state invalid");
        Ok(json!({"rent_lamports":rent,"network_fee_lamports":record["charged_fee_lamports"]}))
    }
    fn builder(&self,c:&mut Chain,p:&Pool)->Result<transaction::TransactionBuilder>{
        let permit=ledger::reserve(&self.ledger,&self.config,&self.request("controlled-attempt")).map_err(|s|anyhow!(s))?;
        transaction::TransactionBuilder::new(&self.config,permit,self.key.clone(),p.route(self.config.allowed_target_wallets[0].parse()?,false),p.mint,
            protocol::SwapIn{user_amount_in:TARGET_INPUT,user_minimum_amount_out:1,max_input_lamports:PRINCIPAL,minimum_front_output:1},c.fresh_hash()?,p.tip).map_err(|s|anyhow!(s))
    }
    fn token(&self,p:&Pool)->Pubkey{utils::get_associated_token_address(&self.key.pubkey(),&p.mint)}
    fn wsol(&self)->Pubkey{utils::get_associated_token_address(&self.key.pubkey(),&WSOL)}
    fn pause(&self)->Instruction{Instruction{program_id:SANDY,accounts:vec![AccountMeta::new(self.key.pubkey(),true),AccountMeta::new(self.state,false)],data:b"SNY2\x03".to_vec()}}
}
fn last_instruction(tx:&VersionedTransaction)->Result<Instruction>{
    let m=match &tx.message{VersionedMessage::Legacy(m)=>m,_=>return Err(anyhow!("Only legacy test instructions supported"))};
    let ix=m.instructions.last().context("No instruction")?;let h=&m.header;
    Ok(Instruction{program_id:m.account_keys[ix.program_id_index as usize],data:ix.data.clone(),accounts:ix.accounts.iter().map(|i|{
        let i=*i as usize;let signer=i<h.num_required_signatures as usize;
        let writable=if signer{i<(h.num_required_signatures-h.num_readonly_signed_accounts)as usize}else{i<m.account_keys.len()-h.num_readonly_unsigned_accounts as usize};
        AccountMeta{pubkey:m.account_keys[i],is_signer:signer,is_writable:writable}
    }).collect()})
}
fn check(checks:&mut Vec<Value>,name:&str,details:Value){println!("RUNTIME_CHECK_OK={name}");checks.push(json!({"name":name,"passed":true,"details":details}));}
fn run_cases(c:&mut Chain,p:&Pool,keys:Vec<Arc<Keypair>>,victim:&Keypair,root:&Path,checks:&mut Vec<Value>)->Result<Value>{
    let cases:Vec<Case>=keys.into_iter().enumerate().map(|(i,k)|Case::new(k,victim.pubkey(),p,root,&format!("case-{i}"))).collect();
    let mut fixed=vec![];for (i,a) in cases.iter().enumerate(){fixed.push(a.initialize(c,p,&format!("initialize-{i}"))?);}
    check(checks,"sbf_initialization_and_fixed_costs",json!(fixed));
    let a=&cases[0];let config_path=root.join("success-config.json");fs::write(&config_path,serde_json::to_vec(&a.config)?)?;
    config::Config::load(&config_path).map_err(|e|anyhow!(e))?;
    let mut oversized=a.request("too-big");oversized.total_principal_lamports=PRINCIPAL+1;
    ensure!(ledger::reserve(&a.ledger,&a.config,&oversized).is_err() && !a.ledger.exists(),"Over-cap request reached the chain");
    check(checks,"oversized_request_rejected_before_submission",json!({"charged_fee_lamports":0}));
    let before_w=c.amount(a.wsol())?;let before_t=c.amount(a.token(p))?;let before_native=c.client.get_balance(&a.key.pubkey())?;
    let tip_before=c.client.get_balance(&p.tip)?;let builder=a.builder(c,p)?;
    let front=c.submit("split-success-front",&builder.front_transaction().map_err(|e|anyhow!(e))?,true,NETWORK_CAP)?;
    let active=c.state(a.state)?;ensure!(active.active && active.actual_input_spent<=PRINCIPAL && active.purchased_token_amount>0,"Entry tracking invalid");
    ensure!(c.amount(a.token(p))?-before_t==active.purchased_token_amount,"Purchased amount includes pre-existing holdings");
    let target=c.transaction(vec![p.target_swap(victim.pubkey())],victim,&[],0)?;let middle=c.submit("split-success-controlled-target",&target,true,NETWORK_CAP)?;
    let back=c.submit("split-success-back",&builder.back_transaction().map_err(|e|anyhow!(e))?,true,NETWORK_CAP)?;
    let final_s=c.state(a.state)?;let after_w=c.amount(a.wsol())?;let after_native=c.client.get_balance(&a.key.pubkey())?;
    let owner_fees=front["charged_fee_lamports"].as_u64().unwrap()+back["charged_fee_lamports"].as_u64().unwrap();
    let all_fees=owner_fees+middle["charged_fee_lamports"].as_u64().unwrap();
    ensure!(!final_s.active && c.amount(a.token(p))?==before_t,"Exit sold previous holdings or failed to close");
    ensure!(after_w>before_w && before_native-after_native==owner_fees+TIP,"Gross profit/fees/tip do not reconcile");
    ensure!(c.client.get_balance(&p.tip)?-tip_before==TIP && all_fees<=NETWORK_CAP,"Tip or fee budget incorrect");
    ensure!(final_s.budget.committed==PRINCIPAL+NETWORK_CAP+TIP && final_s.budget.attempts==1,"On-chain exposure not retained");
    ensure!(ledger::reserve(&a.ledger,&a.config,&a.request("retry")).is_err(),"Successful trade replenished the exposure budget");
    check(checks,"real_raydium_sbf_local_buy_target_sell",json!({"input_spent_lamports":active.actual_input_spent,"tokens_bought":active.purchased_token_amount,
        "previous_tokens_preserved":before_t,"gross_wsol_change_lamports":after_w-before_w,"network_fees_all_owned_wallets_lamports":all_fees,
        "tip_lamports":TIP,"controlled_cycle_net_lamports":(after_w-before_w)as i128-all_fees as i128-TIP as i128,
        "synthetic_scenario_not_performance_claim":true}));
    let before_state=c.client.get_account_data(&a.state)?;
    let mut bad=a.pause();bad.accounts[0]=AccountMeta::new(victim.pubkey(),true);
    let tx=c.transaction(vec![bad],victim,&[],0)?;c.submit("unauthorized-pause",&tx,false,NETWORK_CAP)?;
    ensure!(c.client.get_account_data(&a.state)?==before_state,"Another wallet changed the state");
    check(checks,"unauthorized_state_change_rejected_by_sbf",json!({"state_unchanged":true}));

    let b=&cases[1];let builder=b.builder(c,p)?;c.submit("split-failure-front",&builder.front_transaction().map_err(|e|anyhow!(e))?,true,NETWORK_CAP)?;
    let entry_state=c.client.get_account_data(&b.state)?;let balances=(c.amount(b.wsol())?,c.amount(b.token(p))?,c.amount(p.coin_vault)?,c.amount(p.pc_vault)?);
    let native_before=c.client.get_balance(&b.key.pubkey())?;
    let failed=c.submit("split-failure-back-no-favorable-target",&builder.back_transaction().map_err(|e|anyhow!(e))?,false,NETWORK_CAP)?;
    ensure!(c.client.get_account_data(&b.state)?==entry_state && c.state(b.state)?.active,"Failed exit changed the prior successful entry");
    ensure!((c.amount(b.wsol())?,c.amount(b.token(p))?,c.amount(p.coin_vault)?,c.amount(p.pc_vault)?)==balances,"Failed exit changed token/pool balances");
    ensure!(native_before-c.client.get_balance(&b.key.pubkey())?==failed["charged_fee_lamports"].as_u64().unwrap(),"Failed transaction fee missing");
    let tx=c.transaction(vec![b.pause()],&b.key,&[],0)?;c.submit("pause-open-position",&tx,true,NETWORK_CAP)?;
    ensure!(c.state(b.state)?.active && c.state(b.state)?.budget.halted,"Pause concealed or removed the open position");
    let tx=c.transaction(vec![last_instruction(&builder.back_transaction().map_err(|e|anyhow!(e))?)?],&b.key,&[],0)?;
    c.submit("paused-exit-still-requires-profit",&tx,false,NETWORK_CAP)?;
    ensure!(c.state(b.state)?.active,"Unexpected automatic liquidation");
    check(checks,"split_exit_failure_keeps_position_and_charges_fee",json!({"position_remains_open":true,"failed_exit_fee_lamports":failed["charged_fee_lamports"],
        "emergency_pause_is_not_a_liquidation":true,"finding":"CRITICAL: separate entry can succeed while profit-protected exit fails"}));

    let d=&cases[2];let stop=PathBuf::from(format!("{}.STOP",d.ledger.display()));fs::write(&stop,b"test only")?;
    ensure!(ledger::reserve(&d.ledger,&d.config,&d.request("stop")).is_err() && !d.ledger.exists(),"Emergency stop failed before entry");fs::remove_file(&stop)?;
    check(checks,"emergency_file_blocks_new_entry",json!({"no_signature_or_send":true}));
    let builder=d.builder(c,p)?;let before=(c.amount(d.wsol())?,c.amount(d.token(p))?,c.amount(p.coin_vault)?,c.amount(p.pc_vault)?);
    let before_state=c.client.get_account_data(&d.state)?;let native_before=c.client.get_balance(&d.key.pubkey())?;
    let atomic=c.transaction(vec![last_instruction(&builder.front_transaction().map_err(|e|anyhow!(e))?)?,last_instruction(&builder.back_transaction().map_err(|e|anyhow!(e))?)?],&d.key,&[],0)?;
    let failed=c.submit("atomic-failure-reverts-entry-and-exit",&atomic,false,NETWORK_CAP)?;
    ensure!(before==(c.amount(d.wsol())?,c.amount(d.token(p))?,c.amount(p.coin_vault)?,c.amount(p.pc_vault)?),"Atomic failure did not roll back swaps");
    ensure!(c.client.get_account_data(&d.state)?==before_state && !c.state(d.state)?.active,"Atomic failure did not roll back program state");
    ensure!(native_before-c.client.get_balance(&d.key.pubkey())?==failed["charged_fee_lamports"].as_u64().unwrap(),"Atomic failure fee incorrect");
    ensure!(ledger::reserve(&d.ledger,&d.config,&d.request("retry")).is_err(),"Failed atomic attempt reset client budget");
    check(checks,"atomic_failure_rolls_back_all_but_fee",json!({"tokens_pool_and_state_restored":true,"charged_fee_lamports":failed["charged_fee_lamports"],"client_reservation_retained":true,"onchain_counter_rolled_back":true}));

    let e=&cases[3];let builder=e.builder(c,p)?;let before=(c.amount(e.wsol())?,c.amount(e.token(p))?);let tip_before=c.client.get_balance(&p.tip)?;
    let atomic=c.transaction(vec![last_instruction(&builder.front_transaction().map_err(|s|anyhow!(s))?)?,p.target_swap(victim.pubkey()),last_instruction(&builder.back_transaction().map_err(|s|anyhow!(s))?)?],&e.key,&[victim],0)?;
    let result=c.submit("atomic-success-controlled-owned-wallets",&atomic,true,NETWORK_CAP)?;
    ensure!(!c.state(e.state)?.active && c.amount(e.token(p))?==before.1 && c.amount(e.wsol())?>before.0,"Atomic controlled cycle invalid");
    ensure!(c.client.get_balance(&p.tip)?-tip_before==TIP,"Atomic tip invalid");
    check(checks,"atomic_owned_wallet_cycle_succeeds",json!({"gross_wsol_change_lamports":c.amount(e.wsol())?-before.0,"network_fee_lamports":result["charged_fee_lamports"],"tip_lamports":TIP,
        "not_a_proof_of_jito_bundle_atomicity":true,"requires_signatures_of_both_controlled_wallets":true}));
    let before_native=c.client.get_balance(&e.key.pubkey())?;let calls=c.transactions.len();
    let high_fee=Message::new_with_blockhash(&[ComputeBudgetInstruction::set_compute_unit_limit(300_000),ComputeBudgetInstruction::set_compute_unit_price(1_000_000_000),e.pause()],Some(&e.key.pubkey()),&c.fresh_hash()?);
    let quote=c.client.get_fee_for_message(&high_fee)?;ensure!(quote>NETWORK_CAP,"High-fee rejection test not meaningful");
    ensure!(c.transactions.len()==calls && c.client.get_balance(&e.key.pubkey())?==before_native,"Fee guard test submitted a transaction");
    check(checks,"high_fee_quote_refused_before_signature",json!({"quoted_fee_lamports":quote,"ceiling_lamports":NETWORK_CAP,"signed":false,"sent":false,"scope":"harness guard; production transport remains disabled"}));
    let open=c.state(b.state)?;Ok(json!({"fixed_setup_costs":fixed,"open_position_after_split_failure":{"active":open.active,"paused":open.budget.halted,
        "principal_spent_lamports":open.actual_input_spent,"tokens_held":open.purchased_token_amount},"ready_for_real_funds":false,
        "blocking_findings":["Separate transactions can leave a position open; pause cannot close at a loss","Owned-wallet atomic transaction is not a verified Jito bundle path","Live fee and submission guard not implemented in the disabled production transport"]}))
}
fn main()->Result<()> {
    ensure!(std::env::var("GITHUB_ACTIONS").as_deref()==Ok("true"),"Disposable GitHub CI only");
    let args:Vec<String>=std::env::args().collect();ensure!(args.len()==5,"Expected validator, Sandy SBF, Raydium SBF, new test directory");
    let temp=fs::canonicalize(std::env::var("RUNNER_TEMP")?)?;let validator=fs::canonicalize(&args[1])?;
    ensure!(validator.starts_with(&temp)&&validator.file_name().is_some_and(|n|n=="solana-test-validator"),"Unexpected validator path");
    for p in [&args[2],&args[3]]{ensure!(fs::canonicalize(p)?.starts_with(&temp),"Program must be built inside CI scratch");}
    let root=PathBuf::from(&args[4]);ensure!(root.parent().is_some_and(|p|fs::canonicalize(p).ok().as_ref()==Some(&temp)),"Unexpected test directory parent");
    ensure!(!root.exists(),"Test directory already exists; no overwrite");fs::create_dir(&root)?;
    let addr:SocketAddr="127.0.0.1:18899".parse()?;ensure!(TcpStream::connect_timeout(&addr,Duration::from_millis(100)).is_err(),"RPC port already in use");
    let fixtures=root.join("accounts");fs::create_dir(&fixtures)?;let keys:Vec<_>=(0..4).map(|_|Arc::new(Keypair::new())).collect();let victim=Keypair::new();
    let pool=Pool::create(&fixtures,&keys,&victim)?;let log=fs::File::create(root.join("validator.log"))?;
    let child=Command::new(validator).args(["--quiet","--ledger"]).arg(root.join("ledger")).args(["--rpc-port","18899","--faucet-port","18901","--faucet-sol","0","--bind-address","127.0.0.1","--gossip-host","127.0.0.1","--dynamic-port-range","19000-19020","--limit-ledger-size","10000","--mint"])
        .arg(Pubkey::new_from_array([47;32]).to_string()).arg("--account-dir").arg(&fixtures).arg("--bpf-program").arg(SANDY.to_string()).arg(&args[2])
        .arg("--bpf-program").arg(DEX.to_string()).arg(&args[3]).stdout(Stdio::from(log.try_clone()?)).stderr(Stdio::from(log)).spawn()?;
    let mut node=Node(child);let mut c=Chain::connect(&pool,&mut node)?;let mut checks=vec![];
    let result=run_cases(&mut c,&pool,keys,&victim,&root,&mut checks);
    let (status,summary,error)=match result{Ok(summary)=>("LOCAL_RUNTIME_VERIFIED_WITH_BLOCKING_FINDINGS",summary,Value::Null),Err(e)=>("RUNTIME_TEST_FAILED",Value::Null,json!(format!("{e:#}")))};
    let report=json!({"status":status,"mode":"fresh loopback-only genesis in isolated network namespace","genesis_hash":c.genesis.to_string(),"public_cluster_transactions":0,
        "real_funds_used":0,"personal_keys_imported":0,"keys_generated_in_memory_only":true,"pool_model":"official historical Raydium AMM v4 SwapOnly with synthetic genesis reserves",
        "checks":checks,"transactions":c.transactions,"summary":summary,"error":error});
    fs::write(root.join("runtime_result.json"),serde_json::to_vec_pretty(&report)?)?;
    println!("RUNTIME_RESULT_JSON={}",report);ensure!(error.is_null(),"Local runtime tests failed");Ok(())
}
