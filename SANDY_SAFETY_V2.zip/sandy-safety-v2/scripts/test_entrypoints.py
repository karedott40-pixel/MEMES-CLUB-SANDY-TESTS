"""Behavioral offline tests. No real keys or external network are used."""
import copy,json,os,subprocess,sys,tempfile,threading,unittest
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
BINARY=Path(sys.argv.pop(1)).resolve()
def b58(byte):
    chars='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';n=int.from_bytes(bytes([byte])*32,'big');out=''
    while n:n,r=divmod(n,58);out=chars[r]+out
    return out
class Spy(BaseHTTPRequestHandler):
    requests=0
    def do_POST(self):Spy.requests+=1;self.send_error(500)
    def do_GET(self):Spy.requests+=1;self.send_error(500)
    def log_message(self,*args):pass
class Entrypoints(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Spy);threading.Thread(target=self.server.serve_forever,daemon=True).start()
        self.config={'schema_version':2,'mode':'inspect','program_id':b58(42),'payer_public_key':b58(43),'rpc_url':f'http://127.0.0.1:{self.server.server_port}','relay_url':'ws://127.0.0.1:8080','allowed_pools':[b58(44)],'allowed_target_wallets':[b58(45)],'limits':{'max_trade_lamports':100,'max_total_exposure_lamports':220,'max_network_fees_lamports':10,'max_tip_lamports':0,'max_account_cost_lamports':0,'max_attempts':2}}
        self.write('config.json',self.config)
        for name in ['payer.json','victim.json']:self.write(name,{'SECRET_SENTINEL':'not-a-key'})
        Spy.requests=0
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.tmp.cleanup()
        self.assertEqual(Spy.requests,0,'A test entrypoint attempted a network request')
    def write(self,name,data):
        p=self.root/name;p.write_text(json.dumps(data));return p
    def run_cli(self,*args):
        result=subprocess.run([str(BINARY),*map(str,args)],cwd=self.root,env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'SANDY_MODE':'live','RPC_URL':'https://api.mainnet-beta.solana.com','WALLET_PRIVATE_KEY':'SECRET_SENTINEL'},capture_output=True,text=True,timeout=3)
        self.assertNotIn('SECRET_SENTINEL',result.stdout+result.stderr);return result
    def assess(self,name):
        request={'id':name,'pool':b58(44),'target_wallet':b58(45),'total_principal_lamports':100,'total_network_fees_lamports':10,'tip_lamports':0,'account_cost_lamports':0}
        return self.run_cli('--assess',self.root/'config.json',self.write('request.json',request),self.root/'risk.json')
    def test_default_startup_and_live_flags_do_nothing(self):
        for args in [(),('--live',),('--send',)]:self.assertEqual(self.run_cli(*args).returncode,2)
        self.assertFalse((self.root/'risk.json').exists())
    def test_configuration_check_does_not_open_wallet_or_rpc(self):
        result=self.run_cli('--check-config',self.root/'config.json');self.assertEqual(result.returncode,0,result.stderr);self.assertFalse(json.loads(result.stdout)['live_enabled'])
    def test_zero_funding_profile_and_mainnet_are_blocked(self):
        c=copy.deepcopy(self.config);c['limits']={key:0 for key in c['limits']};self.write('config.json',c);self.assertEqual(self.assess('zero').returncode,2)
        c=copy.deepcopy(self.config);c['rpc_url']='https://api.mainnet-beta.solana.com';self.write('config.json',c);self.assertEqual(self.run_cli('--check-config',self.root/'config.json').returncode,2)
    def test_budget_survives_separate_process_restarts(self):
        self.assertEqual(self.assess('one').returncode,0)
        self.assertEqual(self.assess('two').returncode,0)
        self.assertEqual(self.assess('three').returncode,2)
        record=json.loads((self.root/'risk.json').read_text())['record'];self.assertEqual(record['committed'],220);self.assertEqual(record['attempts'],2)
    def test_kill_switch_prevents_next_process(self):
        self.assertEqual(self.assess('one').returncode,0);(self.root/'risk.json.STOP').touch();self.assertEqual(self.assess('two').returncode,2)
    def test_changed_configuration_cannot_replenish_budget(self):
        self.assertEqual(self.assess('one').returncode,0);self.config['limits']['max_total_exposure_lamports']=1000;self.write('config.json',self.config);self.assertEqual(self.assess('two').returncode,2)
    def test_malformed_or_secret_configuration_is_rejected_without_echo(self):
        self.config['private_key']='SECRET_SENTINEL';self.write('config.json',self.config);self.assertEqual(self.run_cli('--check-config',self.root/'config.json').returncode,2)
    def test_replay_and_corrupted_ledger_do_not_reset_budget(self):
        self.assertEqual(self.assess('one').returncode,0);self.assertEqual(self.assess('one').returncode,2)
        (self.root/'risk.json').write_text('{broken');self.assertEqual(self.assess('two').returncode,2);self.assertEqual((self.root/'risk.json').read_text(),'{broken')
if __name__=='__main__':unittest.main()
