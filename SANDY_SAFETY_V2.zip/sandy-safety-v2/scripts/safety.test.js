'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {spawnSync} = require('node:child_process');
const path = require('node:path');
for (const name of ['relayer.js','initialize.js']) {
  test(name + ' refuses execution before any dependency or key loading', () => {
    const result = spawnSync(process.execPath, [path.join(__dirname,name)], {
      cwd: require('node:os').tmpdir(), encoding:'utf8', timeout:3000,
      env:{PATH:process.env.PATH, SANDY_MODE:'live', RPC_URL:'https://api.mainnet-beta.solana.com', WALLET_PRIVATE_KEY:'SECRET_SENTINEL'}
    });
    assert.equal(result.status,2);
    assert.match(result.stderr,/ARRET/);
    assert.equal(result.stdout,'');
    assert.ok(!result.stderr.includes('SECRET_SENTINEL'));
  });
  test(name + ' import has no startup side effects', () => {
    assert.deepEqual(require(path.join(__dirname,name)),{liveEnabled:false});
  });
}
