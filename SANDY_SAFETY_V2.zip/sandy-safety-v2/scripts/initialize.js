'use strict';
// Unsafe upstream auto-sign/send examples disabled before loading any dependency or key.
if (require.main === module) {
  console.error('ARRET: transactions reelles et chargement de portefeuilles desactives dans cette version.');
  process.exitCode = 2;
}
module.exports = { liveEnabled: false };
