pub struct AmountOut {
    pub amount_out: u64,
    pub new_reserve_a: u64,
    pub new_reserve_b: u64,
}

// k = y * x
fn get_amount_out(amount_in: u64, reserve_a: u64, reserve_b: u64) -> AmountOut {
    let amount_in_128 = u128::from(amount_in);
    let reserve_a_128 = u128::from(reserve_a);
    let reserve_b_128 = u128::from(reserve_b);

    let amount_in_after_fee = amount_in_128 * (10000 - 25) / 10000;

    let numerator = amount_in_after_fee * reserve_b_128;
    let denominator = reserve_a_128 + amount_in_after_fee;

    let amount_out = (numerator / denominator) as u64;

    AmountOut {
        amount_out,
        new_reserve_a: reserve_a + amount_in,
        new_reserve_b: reserve_b - amount_out,
    }
}

pub fn calculate_swap_amount_in(lb:u64,ub:u64,user_amount_in:u64,user_minimum_amount_out:u64,reserve_a:u64,reserve_b:u64)->u64 {
    if lb>ub || reserve_a==0 || reserve_b==0 || reserve_a.checked_add(ub).and_then(|v|v.checked_add(user_amount_in)).is_none() {return 0;}
    let feasible=|amount| {let front=get_amount_out(amount,reserve_a,reserve_b);get_amount_out(user_amount_in,front.new_reserve_a,front.new_reserve_b).amount_out>=user_minimum_amount_out};
    if !feasible(lb) {return 0;}
    let (mut low,mut high)=(lb,ub);
    while low<high {let width=high-low;let mid=low+width/2+width%2;if feasible(mid) {low=mid;}else{high=mid-1;}}
    low
}
#[cfg(test)] mod tests {
    use super::*;
    #[test] fn adjacent_interval_terminates() {assert_eq!(calculate_swap_amount_in(0,1,1,0,1000,1000),1);}
    #[test] fn invalid_or_overflowing_reserves_rejected() {assert_eq!(calculate_swap_amount_in(0,u64::MAX,1,0,1,1000),0);assert_eq!(calculate_swap_amount_in(1,0,1,0,1,1000),0);assert_eq!(calculate_swap_amount_in(0,1,1,0,0,1000),0);}
    #[test] fn widest_safe_interval_terminates() {assert_eq!(calculate_swap_amount_in(0,u64::MAX-1,0,0,1,1000),u64::MAX-1);}
    #[test] fn impossible_minimum_and_empty_interval_are_safe() {assert_eq!(calculate_swap_amount_in(0,10,100,1001,1000,1000),0);assert_eq!(calculate_swap_amount_in(0,0,100,0,1000,1000),0);}
    #[test] fn exhaustive_integer_model_matches_search() {for a in [100u64,1000,10000] {for b in [100u64,1000,10000] {for user in [1u64,10,50] {let normal=get_amount_out(user,a,b).amount_out;for minimum in [0,normal/2,normal,normal+1] {for upper in [1u64,2,5,20,100] {let expected=(0..=upper).filter(|&x|{let front=get_amount_out(x,a,b);get_amount_out(user,front.new_reserve_a,front.new_reserve_b).amount_out>=minimum}).max().unwrap_or(0);assert_eq!(calculate_swap_amount_in(0,upper,user,minimum,a,b),expected);}}}}}}
}
