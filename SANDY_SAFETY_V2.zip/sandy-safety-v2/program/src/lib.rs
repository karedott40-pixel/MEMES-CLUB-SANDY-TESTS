use solana_program::{account_info::AccountInfo,entrypoint,entrypoint::ProgramResult,pubkey::Pubkey};
mod instruction;
mod math;
mod processor;
mod state;
#[path="../../safety/core.rs"] mod guard;
#[path="../../safety/protocol.rs"] mod protocol;
entrypoint!(process_instruction);
// The runtime supplies the deployed program ID. No System Program placeholder.
fn process_instruction(program_id:&Pubkey,accounts:&[AccountInfo],data:&[u8])->ProgramResult {
    processor::Processor::process(program_id,accounts,data)
}
