use borsh::BorshDeserialize;
use solana_program::{account_info::AccountInfo,entrypoint::ProgramResult,instruction::{AccountMeta,Instruction},program::{invoke,invoke_signed},program_error::ProgramError,program_pack::Pack,pubkey,pubkey::Pubkey,rent::Rent,system_instruction,system_program,sysvar::Sysvar};
use spl_token::state::{Account,AccountState};
use crate::{guard::{Budget,Cost,minimum_recovery},instruction::{Initialize,SandyInstruction,SwapIn},math::calculate_swap_amount_in,state::SandwichState};
const RAYDIUM:Pubkey=pubkey!("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8");
const WSOL:Pubkey=pubkey!("So11111111111111111111111111111111111111112");
pub struct Processor;
fn invalid()->ProgramError {ProgramError::InvalidAccountData}
fn risk()->ProgramError {ProgramError::Custom(1000)}
fn expected_state(program:&Pubkey,payer:&Pubkey)->(Pubkey,u8) {Pubkey::find_program_address(&[b"sandwich-state",payer.as_ref()],program)}
fn signer(payer:&AccountInfo)->ProgramResult {
    if !payer.is_signer {return Err(ProgramError::MissingRequiredSignature);}
    if !payer.is_writable || payer.key==&system_program::id() {return Err(ProgramError::InvalidArgument);}
    Ok(())
}
fn state(program:&Pubkey,accounts:&[AccountInfo])->Result<SandwichState,ProgramError> {
    let payer=accounts.first().ok_or(ProgramError::NotEnoughAccountKeys)?;
    let info=accounts.get(1).ok_or(ProgramError::NotEnoughAccountKeys)?;
    signer(payer)?;
    if info.owner!=program || !info.is_writable || info.data_len()!=SandwichState::LEN {return Err(invalid());}
    if expected_state(program,payer.key).0!=*info.key {return Err(ProgramError::InvalidSeeds);}
    let value=SandwichState::try_from_slice(&info.try_borrow_data()?).map_err(|_|invalid())?;
    if value.version!=2 || value.authority!=*payer.key {return Err(ProgramError::IllegalOwner);}
    value.limits.validate().map_err(|_|risk())?;
    Ok(value)
}
fn store(info:&AccountInfo,value:&SandwichState)->ProgramResult {
    let bytes=borsh::to_vec(value).map_err(|_|invalid())?;
    if bytes.len()!=info.data_len() {return Err(invalid());}
    info.try_borrow_mut_data()?.copy_from_slice(&bytes);Ok(())
}
fn token(info:&AccountInfo)->Result<Account,ProgramError> {
    if info.owner!=&spl_token::id() {return Err(ProgramError::IllegalOwner);}
    let data=Account::unpack(&info.try_borrow_data()?)?;
    if data.state!=AccountState::Initialized {return Err(invalid());}
    Ok(data)
}
fn key_at(data:&[u8],offset:usize)->Result<Pubkey,ProgramError> {
    let bytes:[u8;32]=data.get(offset..offset+32).ok_or_else(invalid)?.try_into().map_err(|_|invalid())?;
    Ok(Pubkey::new_from_array(bytes))
}
// Route is the 17-account Raydium AMM v4 SwapBaseIn layout. No invented placeholders.
// Outer accounts: payer, state, route[0..17], Raydium program; backrun adds tip + system.
fn route<'a,'info>(accounts:&'a [AccountInfo<'info>],front:bool)->Result<(&'a [AccountInfo<'info>],Account,Account),ProgramError> {
    let list=accounts.get(2..19).ok_or(ProgramError::NotEnoughAccountKeys)?;
    let dex=accounts.get(19).ok_or(ProgramError::NotEnoughAccountKeys)?;
    if dex.key!=&RAYDIUM || !dex.executable || list[0].key!=&spl_token::id() || !list[0].executable
        || list[1].owner!=&RAYDIUM || list[16].key!=accounts[0].key || !list[16].is_signer {return Err(ProgramError::IncorrectProgramId);}
    let amm=list[1].try_borrow_data()?;
    if amm.len()!=752 || key_at(&amm,336)?!=*list[4].key || key_at(&amm,368)?!=*list[5].key {return Err(invalid());}
    let a=token(&list[4])?;let b=token(&list[5])?;
    if a.owner!=*list[2].key || b.owner!=*list[2].key || a.mint!=key_at(&amm,400)? || b.mint!=key_at(&amm,432)? {return Err(invalid());}
    let input=token(&list[14])?;let output=token(&list[15])?;
    for (account,data) in [(&list[14],&input),(&list[15],&output)] {
        if data.owner!=*accounts[0].key || data.delegate.is_some()
            || spl_associated_token_account::get_associated_token_address(accounts[0].key,&data.mint)!=*account.key {return Err(ProgramError::IllegalOwner);}
    }
    if input.mint==output.mint || !((input.mint==a.mint && output.mint==b.mint)||(input.mint==b.mint && output.mint==a.mint))
        || (front && input.mint!=WSOL) || (!front && output.mint!=WSOL) {return Err(invalid());}
    Ok((list,input,output))
}
fn swap<'info>(accounts:&[AccountInfo<'info>],amount:u64,minimum:u64)->ProgramResult {
    if amount==0 || minimum==0 {return Err(ProgramError::InvalidArgument);}
    let list=accounts.get(2..19).ok_or(ProgramError::NotEnoughAccountKeys)?;
    let metas=list.iter().enumerate().map(|(i,a)|{
        if matches!(i,0|2|6|13|16) {AccountMeta::new_readonly(*a.key,i==16)}else{AccountMeta::new(*a.key,false)}
    }).collect();
    let mut data=vec![9];data.extend_from_slice(&amount.to_le_bytes());data.extend_from_slice(&minimum.to_le_bytes());
    let instruction=Instruction{program_id:RAYDIUM,accounts:metas,data};
    let mut infos=list.to_vec();infos.push(accounts[19].clone());invoke(&instruction,&infos)
}
impl Processor {
    pub fn process(program:&Pubkey,accounts:&[AccountInfo],data:&[u8])->ProgramResult {
        if program==&system_program::id() {return Err(ProgramError::IncorrectProgramId);}
        match SandyInstruction::unpack(data)? {
            SandyInstruction::Initialize(args)=>Self::initialize(program,accounts,args),
            SandyInstruction::SwapIn(args)=>Self::front(program,accounts,args),
            SandyInstruction::SwapOut=>Self::back(program,accounts),
            SandyInstruction::Pause=>{let mut value=state(program,accounts)?;value.budget.halted=true;store(&accounts[1],&value)},
        }
    }
    fn initialize(program:&Pubkey,accounts:&[AccountInfo],args:Initialize)->ProgramResult {
        if accounts.len()!=3 {return Err(ProgramError::NotEnoughAccountKeys);}
        signer(&accounts[0])?;args.limits.validate().map_err(|_|risk())?;
        if args.tip_lamports>args.limits.max_tip_lamports {return Err(risk());}
        if accounts[2].key!=&system_program::id() || !accounts[2].executable || !accounts[1].is_writable {return Err(ProgramError::IncorrectProgramId);}
        let (address,bump)=expected_state(program,accounts[0].key);
        if *accounts[1].key!=address {return Err(ProgramError::InvalidSeeds);}
        // Initialization cannot overwrite counters, increase the budget or resume a paused state.
        if !accounts[1].data_is_empty() {return Err(ProgramError::AccountAlreadyInitialized);}
        let rent=Rent::get()?.minimum_balance(SandwichState::LEN);
        invoke_signed(&system_instruction::create_account(accounts[0].key,&address,rent,SandwichState::LEN as u64,program),
            accounts,&[&[b"sandwich-state",accounts[0].key.as_ref(),&[bump]]])?;
        let value=SandwichState{version:2,authority:*accounts[0].key,limits:args.limits,budget:Budget::default(),tip_lamports:args.tip_lamports,tip_receiver:args.tip_receiver,
            minimum_profit_lamports:args.minimum_profit_lamports,active:false,pool:Pubkey::default(),token_mint:Pubkey::default(),preswap_sol_balance:0,preswap_token_balance:0,
            actual_input_spent:0,purchased_token_amount:0};
        store(&accounts[1],&value)
    }
    fn front(program:&Pubkey,accounts:&[AccountInfo],args:SwapIn)->ProgramResult {
        let mut value=state(program,accounts)?;
        if value.active || args.max_input_lamports==0 || args.minimum_front_output==0 || args.user_amount_in==0 || args.user_minimum_amount_out==0 {return Err(ProgramError::InvalidArgument);}
        let (list,input,output)=route(accounts,true)?;
        if args.max_input_lamports>input.amount {return Err(ProgramError::InsufficientFunds);}
        let cost=Cost{principal:args.max_input_lamports,network_fees:value.limits.max_network_fees_lamports,tip:value.tip_lamports,account_cost:value.limits.max_account_cost_lamports};
        value.budget.reserve(&value.limits,cost).map_err(|_|risk())?;
        let a=token(&list[4])?;let b=token(&list[5])?;
        let (reserve_in,reserve_out)=if a.mint==WSOL {(a.amount,b.amount)}else{(b.amount,a.amount)};
        let amount=calculate_swap_amount_in(0,args.max_input_lamports,args.user_amount_in,args.user_minimum_amount_out,reserve_in,reserve_out);
        if amount==0 || amount>args.max_input_lamports {return Err(risk());}
        value.preswap_sol_balance=input.amount;value.preswap_token_balance=output.amount;
        value.pool=*list[1].key;value.token_mint=output.mint;value.active=true;
        swap(accounts,amount,args.minimum_front_output)?;
        value.actual_input_spent=input.amount.checked_sub(token(&list[14])?.amount).ok_or_else(invalid)?;
        value.purchased_token_amount=token(&list[15])?.amount.checked_sub(output.amount).ok_or_else(invalid)?;
        if value.actual_input_spent>args.max_input_lamports || value.purchased_token_amount<args.minimum_front_output {return Err(risk());}
        store(&accounts[1],&value)
    }
    fn back(program:&Pubkey,accounts:&[AccountInfo])->ProgramResult {
        let mut value=state(program,accounts)?;
        // Pause blocks new entries, but does not prevent closing an existing bounded entry.
        if !value.active {return Err(ProgramError::InvalidArgument);}
        let (list,input,_output)=route(accounts,false)?;
        if *list[1].key!=value.pool || input.mint!=value.token_mint || input.amount<value.purchased_token_amount {return Err(invalid());}
        let overhead=Cost{principal:0,network_fees:value.limits.max_network_fees_lamports,tip:value.tip_lamports,account_cost:value.limits.max_account_cost_lamports}.overhead().map_err(|_|risk())?;
        let minimum=minimum_recovery(value.actual_input_spent,overhead,value.minimum_profit_lamports).map_err(|_|risk())?;
        let tip=accounts.get(20).ok_or(ProgramError::NotEnoughAccountKeys)?;let system=accounts.get(21).ok_or(ProgramError::NotEnoughAccountKeys)?;
        if system.key!=&system_program::id() || !system.executable || (value.tip_lamports>0 && tip.key.to_bytes()!=value.tip_receiver) {return Err(ProgramError::IncorrectProgramId);}
        swap(accounts,value.purchased_token_amount,minimum)?;
        let required=minimum_recovery(value.preswap_sol_balance,overhead,value.minimum_profit_lamports).map_err(|_|risk())?;
        if token(&list[15])?.amount<required {return Err(risk());}
        if value.tip_lamports>0 {invoke(&system_instruction::transfer(accounts[0].key,tip.key,value.tip_lamports),&[accounts[0].clone(),tip.clone(),system.clone()])?;}
        value.active=false;value.actual_input_spent=0;value.purchased_token_amount=0;store(&accounts[1],&value)
    }
}
#[cfg(test)] mod tests {
    use super::*;use crate::guard::Limits;
    fn account(key:Pubkey,owner:Pubkey,data:Vec<u8>,sign:bool,write:bool,exe:bool)->AccountInfo<'static> {
        AccountInfo::new(Box::leak(Box::new(key)),sign,write,Box::leak(Box::new(1)),Box::leak(data.into_boxed_slice()),Box::leak(Box::new(owner)),exe,0)
    }
    fn setup()->(Pubkey,Vec<AccountInfo<'static>>) {
        let program=Pubkey::new_unique();let payer=Pubkey::new_unique();
        let value=SandwichState{version:2,authority:payer,limits:Limits{max_trade_lamports:100,max_total_exposure_lamports:220,max_network_fees_lamports:10,max_tip_lamports:0,max_account_cost_lamports:0,max_attempts:2},budget:Budget{attempts:1,committed:110,halted:false},tip_lamports:0,tip_receiver:[0;32],minimum_profit_lamports:0,active:false,pool:Pubkey::default(),token_mint:Pubkey::default(),preswap_sol_balance:0,preswap_token_balance:0,actual_input_spent:0,purchased_token_amount:0};
        (program,vec![account(payer,system_program::id(),vec![],true,true,false),account(expected_state(&program,&payer).0,program,borsh::to_vec(&value).unwrap(),false,true,false)])
    }
    #[test] fn system_program_placeholder_rejected() {assert_eq!(Processor::process(&system_program::id(),&[],b"SNY2\x03"),Err(ProgramError::IncorrectProgramId));}
    #[test] fn pause_preserves_authority_budget_and_counters() {let (p,a)=setup();Processor::process(&p,&a,b"SNY2\x03").unwrap();let v=state(&p,&a).unwrap();assert!(v.budget.halted);assert_eq!(v.budget.committed,110);assert_eq!(v.budget.attempts,1);}
    #[test] fn wrong_signer_or_state_owner_cannot_change_limits() {let (p,mut a)=setup();a[0].is_signer=false;assert!(Processor::process(&p,&a,b"SNY2\x03").is_err());a[0].is_signer=true;a[1].owner=Box::leak(Box::new(Pubkey::new_unique()));assert!(Processor::process(&p,&a,b"SNY2\x03").is_err());}
    #[test] fn another_wallet_cannot_take_state() {let (p,mut a)=setup();a[0].key=Box::leak(Box::new(Pubkey::new_unique()));assert!(Processor::process(&p,&a,b"SNY2\x03").is_err());}
    #[test] fn reinitialization_cannot_reset_spending() {let (p,mut a)=setup();a.push(account(system_program::id(),system_program::id(),vec![],false,false,true));let before=a[1].try_borrow_data().unwrap().to_vec();let value=state(&p,&a).unwrap();let args=Initialize{limits:value.limits,tip_lamports:0,tip_receiver:[0;32],minimum_profit_lamports:0};let data=crate::protocol::encode(0,&args).unwrap();assert_eq!(Processor::process(&p,&a,&data),Err(ProgramError::AccountAlreadyInitialized));assert_eq!(a[1].try_borrow_data().unwrap().to_vec(),before);}
    #[test] fn missing_route_cannot_start_a_swap() {let (p,a)=setup();let args=SwapIn{user_amount_in:10,user_minimum_amount_out:1,max_input_lamports:10,minimum_front_output:1};let before=a[1].try_borrow_data().unwrap().to_vec();assert!(Processor::process(&p,&a,&crate::protocol::encode(1,&args).unwrap()).is_err());assert_eq!(a[1].try_borrow_data().unwrap().to_vec(),before);}
    #[test] fn zero_minimum_cannot_start_a_swap() {let (p,a)=setup();let args=SwapIn{user_amount_in:10,user_minimum_amount_out:1,max_input_lamports:10,minimum_front_output:0};assert_eq!(Processor::process(&p,&a,&crate::protocol::encode(1,&args).unwrap()),Err(ProgramError::InvalidArgument));}
    #[test] fn backrun_without_front_is_rejected() {let (p,a)=setup();assert_eq!(Processor::process(&p,&a,b"SNY2\x02"),Err(ProgramError::InvalidArgument));}
    #[test] fn truncated_pool_data_never_panics() {for n in 0..464 {assert!(key_at(&vec![0;n],432).is_err());}}
}
