use borsh::{BorshDeserialize,BorshSerialize};
use solana_program::pubkey::Pubkey;
use crate::guard::{Limits,Budget};
#[derive(BorshDeserialize,BorshSerialize,Clone)]
pub struct SandwichState {
    pub version:u8, pub authority:Pubkey, pub limits:Limits, pub budget:Budget,
    pub tip_lamports:u64, pub tip_receiver:[u8;32], pub minimum_profit_lamports:u64,
    pub active:bool, pub pool:Pubkey, pub token_mint:Pubkey,
    pub preswap_sol_balance:u64, pub preswap_token_balance:u64,
    pub actual_input_spent:u64, pub purchased_token_amount:u64,
}
impl SandwichState {
    pub const LEN:usize=1+32+(5*8+4)+(4+8+1)+8+32+8+1+32+32+8+8+8+8;
}
#[cfg(test)] mod tests {
    use super::*;
    #[test] fn state_size_matches_serialized_layout() {let state=SandwichState{version:2,authority:Pubkey::new_unique(),limits:Limits{max_trade_lamports:1,max_total_exposure_lamports:2,max_network_fees_lamports:1,max_tip_lamports:0,max_account_cost_lamports:0,max_attempts:1},budget:Budget::default(),tip_lamports:0,tip_receiver:[0;32],minimum_profit_lamports:0,active:false,pool:Pubkey::default(),token_mint:Pubkey::default(),preswap_sol_balance:0,preswap_token_balance:0,actual_input_spent:0,purchased_token_amount:0};assert_eq!(borsh::to_vec(&state).unwrap().len(),SandwichState::LEN);}
}
