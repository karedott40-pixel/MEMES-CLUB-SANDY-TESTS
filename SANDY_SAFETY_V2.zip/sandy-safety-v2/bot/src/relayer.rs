use serde::{Deserialize, Serialize};
use tokio::sync::mpsc::Sender;
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PendingTransaction { pub transactions:Vec<Packet> }
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Packet { pub data:Vec<u8>, pub meta:Option<Meta> }
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Meta { pub size:u64 }
pub async fn forward_incoming_transactions(_sender:Sender<PendingTransaction>)->Result<(),String> {
    Err("Relais reseau desactive dans le profil de securisation".into())
}
#[cfg(test)] mod tests {
    use super::*;
    #[tokio::test] async fn relay_does_not_connect_on_start() {let (sender,_)=tokio::sync::mpsc::channel(1);assert!(forward_incoming_transactions(sender).await.is_err());}
}
