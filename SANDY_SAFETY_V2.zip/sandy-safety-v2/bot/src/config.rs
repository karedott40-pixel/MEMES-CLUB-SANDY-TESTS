use crate::guard::{Cost, Limits};
use serde::{Deserialize, Serialize};
use solana_sdk::{hash::hash, pubkey::Pubkey, system_program};
use std::{fs, path::Path, str::FromStr};

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LimitConfig {
    pub max_trade_lamports:u64, pub max_total_exposure_lamports:u64,
    pub max_network_fees_lamports:u64, pub max_tip_lamports:u64,
    pub max_account_cost_lamports:u64, pub max_attempts:u32,
}
impl LimitConfig { pub fn limits(&self)->Limits { Limits {
    max_trade_lamports:self.max_trade_lamports, max_total_exposure_lamports:self.max_total_exposure_lamports,
    max_network_fees_lamports:self.max_network_fees_lamports, max_tip_lamports:self.max_tip_lamports,
    max_account_cost_lamports:self.max_account_cost_lamports,max_attempts:self.max_attempts } } }

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    pub schema_version:u32, pub mode:String,
    pub program_id:Option<String>, pub payer_public_key:Option<String>,
    pub rpc_url:String, pub relay_url:String,
    pub allowed_pools:Vec<String>, pub allowed_target_wallets:Vec<String>,
    pub limits:LimitConfig,
}

fn public_key(text:&str)->Result<Pubkey,String> {
    let key=Pubkey::from_str(text).map_err(|_|"Adresse publique invalide".to_string())?;
    if key==system_program::id() { return Err("Adresse provisoire/System Program interdite".into()); }
    Ok(key)
}
fn local_endpoint(text:&str, schemes:&[&str])->Result<(),String> {
    let url=reqwest::Url::parse(text).map_err(|_|"Adresse de service invalide".to_string())?;
    if !schemes.contains(&url.scheme()) || !matches!(url.host_str(),Some("localhost"|"127.0.0.1"|"[::1]"))
        || !url.username().is_empty() || url.password().is_some() || url.query().is_some()
        || url.fragment().is_some() || url.path()!="/" {
        return Err("Profil actuel limite aux services locaux, sans identifiant ni parametre secret".into());
    }
    Ok(())
}
pub fn bounded_text(path:&Path,maximum:u64)->Result<String,String> {
    let meta=fs::symlink_metadata(path).map_err(|_|"Fichier inaccessible".to_string())?;
    if !meta.is_file() || meta.file_type().is_symlink() || meta.len()>maximum { return Err("Fichier non regulier ou trop volumineux".into()); }
    fs::read_to_string(path).map_err(|_|"Lecture du fichier impossible".to_string())
}
impl Config {
    pub fn load(path:&Path)->Result<Self,String> {
        let text=bounded_text(path,65_536)?;
        // Never echo the rejected JSON: it could contain an accidentally pasted secret.
        let cfg:Self=serde_json::from_str(&text).map_err(|_|"Configuration JSON invalide ou champ non autorise".to_string())?;
        cfg.validate()?; Ok(cfg)
    }
    pub fn validate(&self)->Result<(),String> {
        if self.schema_version!=2 || self.mode!="inspect" {
            return Err("Seul le mode inspect est autorise; aucune transaction reelle dans cette version".into());
        }
        local_endpoint(&self.rpc_url,&["http","https"])?;
        local_endpoint(&self.relay_url,&["ws","wss"])?;
        for s in self.program_id.iter().chain(self.payer_public_key.iter()).chain(self.allowed_pools.iter()).chain(self.allowed_target_wallets.iter()) { public_key(s)?; }
        if self.program_id.is_some() && self.program_id==self.payer_public_key { return Err("Programme et payeur doivent etre distincts".into()); }
        if self.allowed_pools.len()>100 || self.allowed_target_wallets.len()>100 { return Err("Liste d'autorisation trop grande".into()); }
        self.limits.limits().validate().map_err(|_|"Limites incoherentes".into())
    }
    pub fn fingerprint(&self)->Result<String,String> {
        Ok(hash(&serde_json::to_vec(self).map_err(|_|"Configuration non serialisable".to_string())?).to_string())
    }
    pub fn authorize_request(&self,request:&Request)->Result<Cost,String> {
        self.validate()?;
        if self.program_id.is_none() || self.payer_public_key.is_none() { return Err("Adresses de programme/payeur non configurees".into()); }
        if !self.allowed_pools.contains(&request.pool) || !self.allowed_target_wallets.contains(&request.target_wallet) { return Err("Pool ou portefeuille cible hors liste autorisee".into()); }
        if request.id.is_empty() || request.id.len()>64 || !request.id.bytes().all(|b|b.is_ascii_alphanumeric() || b==b'-' || b==b'_') { return Err("Identifiant d'essai invalide".into()); }
        Ok(Cost{principal:request.total_principal_lamports,network_fees:request.total_network_fees_lamports,
            tip:request.tip_lamports,account_cost:request.account_cost_lamports})
    }
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Request {
    pub id:String, pub pool:String, pub target_wallet:String,
    pub total_principal_lamports:u64, pub total_network_fees_lamports:u64,
    pub tip_lamports:u64, pub account_cost_lamports:u64,
}

#[cfg(test)]
pub mod tests {
    use super::*;
    pub fn config()->Config {
        Config{schema_version:2,mode:"inspect".into(),program_id:Some(Pubkey::new_unique().to_string()),payer_public_key:Some(Pubkey::new_unique().to_string()),
            rpc_url:"http://127.0.0.1:8899".into(),relay_url:"ws://127.0.0.1:8080".into(),allowed_pools:vec![Pubkey::new_unique().to_string()],allowed_target_wallets:vec![Pubkey::new_unique().to_string()],
            limits:LimitConfig{max_trade_lamports:100,max_total_exposure_lamports:220,max_network_fees_lamports:10,max_tip_lamports:0,max_account_cost_lamports:0,max_attempts:2}}
    }
    pub fn request(c:&Config,id:&str)->Request { Request{id:id.into(),pool:c.allowed_pools[0].clone(),target_wallet:c.allowed_target_wallets[0].clone(),total_principal_lamports:100,total_network_fees_lamports:10,tip_lamports:0,account_cost_lamports:0} }
    #[test] fn strict_local_profile_is_valid() { config().validate().unwrap(); }
    #[test] fn mainnet_and_similar_looking_hosts_rejected() { for url in ["https://api.mainnet-beta.solana.com","http://localhost.evil/","http://127.0.0.1@evil/","file:///tmp/a","http://user:password@127.0.0.1/","http://127.0.0.1/?api-key=secret"] { let mut c=config();c.rpc_url=url.into();assert!(c.validate().is_err()); } }
    #[test] fn live_mode_and_old_schema_cannot_enable_sending() { let mut c=config();c.mode="live".into();assert!(c.validate().is_err()); c.mode="inspect".into();c.schema_version=1;assert!(c.validate().is_err()); }
    #[test] fn placeholder_and_malformed_ids_rejected() { for value in ["11111111111111111111111111111111","not-a-key"] { let mut c=config();c.program_id=Some(value.into());assert!(c.validate().is_err()); } }
    #[test] fn missing_addresses_block_assessment() { let mut c=config();let r=request(&c,"x");c.program_id=None;assert!(c.authorize_request(&r).is_err()); }
    #[test] fn arbitrary_wallet_and_pool_rejected() { let c=config();let mut r=request(&c,"x");r.target_wallet=Pubkey::new_unique().to_string();assert!(c.authorize_request(&r).is_err()); r=request(&c,"x");r.pool=Pubkey::new_unique().to_string();assert!(c.authorize_request(&r).is_err()); }
    #[test] fn changed_limits_change_fingerprint() { let mut c=config();let old=c.fingerprint().unwrap();c.limits.max_attempts=1;assert_ne!(old,c.fingerprint().unwrap()); }
    #[test] fn unknown_secret_field_negative_and_float_are_rejected() { let c=config();let mut value=serde_json::to_value(&c).unwrap();value["private_key"]=serde_json::json!("SECRET_SENTINEL");assert!(serde_json::from_value::<Config>(value).is_err());for n in [serde_json::json!(-1),serde_json::json!(1.5),serde_json::json!("10")] {let mut v=serde_json::to_value(&c).unwrap();v["limits"]["max_trade_lamports"]=n;assert!(serde_json::from_value::<Config>(v).is_err());} }
}
