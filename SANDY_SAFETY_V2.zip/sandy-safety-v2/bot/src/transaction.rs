//! Bounded offline builder. There is no transmission endpoint in this release.
use std::{str::FromStr,sync::Arc};
use solana_sdk::{compute_budget::ComputeBudgetInstruction,hash::Hash,instruction::{AccountMeta,Instruction},pubkey,pubkey::Pubkey,signature::Keypair,signer::Signer,transaction::{Transaction,VersionedTransaction}};
use crate::{config::Config,ledger::Reservation,protocol::{self,SwapIn},utils::get_associated_token_address};
const WSOL:Pubkey=pubkey!("So11111111111111111111111111111111111111112");
const RAYDIUM:Pubkey=pubkey!("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8");
pub struct TransactionBuilder {
    program_id:Pubkey,keypair:Arc<Keypair>,route:[Pubkey;17],state:Pubkey,
    args:SwapIn,blockhash:Hash,tip_receiver:Pubkey,token_mint:Pubkey,_reservation:Reservation,
}
impl TransactionBuilder {
    #[allow(clippy::too_many_arguments)]
    pub fn new(cfg:&Config,reservation:Reservation,keypair:Arc<Keypair>,route:[Pubkey;17],
        token_mint:Pubkey,args:SwapIn,blockhash:Hash,tip_receiver:Pubkey)->Result<Self,String> {
        cfg.validate()?;
        let program_id=Pubkey::from_str(cfg.program_id.as_ref().ok_or("Programme non configure")?).map_err(|_|"Programme invalide")?;
        let payer=Pubkey::from_str(cfg.payer_public_key.as_ref().ok_or("Payeur non configure")?).map_err(|_|"Payeur invalide")?;
        if !reservation.matches(cfg) || keypair.pubkey()!=payer || args.max_input_lamports==0
            || args.max_input_lamports>reservation.principal() || args.max_input_lamports>cfg.limits.max_trade_lamports
            || args.minimum_front_output==0 || args.user_amount_in==0 || args.user_minimum_amount_out==0
            || !cfg.allowed_pools.contains(&route[1].to_string()) || !cfg.allowed_target_wallets.contains(&route[16].to_string())
            || route[0]!=spl_token_id() || token_mint==WSOL || token_mint==Pubkey::default() {return Err("Construction refusee: limites, payeur ou route invalides".into());}
        let state=Pubkey::find_program_address(&[b"sandwich-state",payer.as_ref()],&program_id).0;
        Ok(Self{program_id,keypair,route,state,args,blockhash,tip_receiver,token_mint,_reservation:reservation})
    }
    fn accounts(&self,back:bool)->Vec<AccountMeta> {
        let payer=self.keypair.pubkey();let mut route=self.route;
        let wsol=get_associated_token_address(&payer,&WSOL);let token=get_associated_token_address(&payer,&self.token_mint);
        route[14]=if back {token}else{wsol};route[15]=if back {wsol}else{token};route[16]=payer;
        let mut out=vec![AccountMeta::new(payer,true),AccountMeta::new(self.state,false)];
        out.extend(route.iter().enumerate().map(|(i,k)|if matches!(i,0|2|6|13|16){AccountMeta::new_readonly(*k,i==16)}else{AccountMeta::new(*k,false)}));
        out.push(AccountMeta::new_readonly(RAYDIUM,false));
        if back {out.push(AccountMeta::new(self.tip_receiver,false));out.push(AccountMeta::new_readonly(solana_sdk::system_program::id(),false));}
        out
    }
    pub fn front_transaction(&self)->Result<VersionedTransaction,String> {
        let data=protocol::encode(1,&self.args).map_err(|_|"Encodage impossible")?;
        self.build(Instruction{program_id:self.program_id,accounts:self.accounts(false),data})
    }
    pub fn back_transaction(&self)->Result<VersionedTransaction,String> {
        let mut data=protocol::MAGIC.to_vec();data.push(2);
        self.build(Instruction{program_id:self.program_id,accounts:self.accounts(true),data})
    }
    fn build(&self,swap:Instruction)->Result<VersionedTransaction,String> {
        let instructions=[ComputeBudgetInstruction::set_compute_unit_limit(300_000),ComputeBudgetInstruction::set_compute_unit_price(0),swap];
        let mut transaction=Transaction::new_with_payer(&instructions,Some(&self.keypair.pubkey()));
        transaction.try_sign(&[self.keypair.as_ref()],self.blockhash).map_err(|_|"Signature de test impossible")?;
        Ok(VersionedTransaction::from(transaction))
    }
}
fn spl_token_id()->Pubkey {pubkey!("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")}
#[cfg(test)] mod tests {
    use super::*;use crate::{config::tests::{config,request},ledger};
    fn case(cap:u64,minimum:u64,wrong_payer:bool)->Result<TransactionBuilder,String> {
        let mut c=config();let key=Arc::new(Keypair::new());c.payer_public_key=Some(if wrong_payer {Pubkey::new_unique()}else{key.pubkey()}.to_string());
        let dir=std::env::temp_dir().join(format!("sandy-builder-{}",Pubkey::new_unique()));std::fs::create_dir(&dir).unwrap();
        let permit=ledger::reserve(&dir.join("risk.json"),&c,&request(&c,"test"))?;let _=std::fs::remove_dir_all(dir);
        let mut route=[Pubkey::new_unique();17];route[0]=spl_token_id();route[1]=Pubkey::from_str(&c.allowed_pools[0]).unwrap();route[16]=Pubkey::from_str(&c.allowed_target_wallets[0]).unwrap();
        TransactionBuilder::new(&c,permit,key,route,Pubkey::new_unique(),SwapIn{user_amount_in:10,user_minimum_amount_out:1,max_input_lamports:cap,minimum_front_output:minimum},Hash::default(),Pubkey::new_unique())
    }
    #[test] fn over_cap_or_zero_slippage_floor_cannot_be_signed() {assert!(case(101,1,false).is_err());assert!(case(10,0,false).is_err());assert!(case(10,1,true).is_err());}
    #[test] fn signed_instruction_carries_cap_and_payer_specific_state() {
        let builder=case(10,1,false).unwrap();let front=builder.front_transaction().unwrap();let back=builder.back_transaction().unwrap();
        let instruction=front.message.instructions().last().unwrap();assert_eq!(&instruction.data[..5],b"SNY2\x01");
        use borsh::BorshDeserialize;let args=SwapIn::try_from_slice(&instruction.data[5..]).unwrap();assert_eq!(args.max_input_lamports,10);assert_eq!(args.minimum_front_output,1);
        assert_eq!(builder.state,Pubkey::find_program_address(&[b"sandwich-state",builder.keypair.pubkey().as_ref()],&builder.program_id).0);
        assert_eq!(&back.message.instructions().last().unwrap().data,b"SNY2\x02");
        assert_eq!(front.message.instructions().len(),3);assert_eq!(back.message.instructions().len(),3);
    }
}
