//! Offline safety profile. An assessment is never a permission to sign/send.
use std::path::Path;
mod config;
mod ledger;
#[path="../../safety/core.rs"] mod guard;
#[path="../../safety/protocol.rs"] mod protocol;
mod decoder;
mod relayer;
mod transaction;
mod utils;
fn run(args:&[String])->Result<(),String> {
    match args {
        [flag,path] if flag=="--check-config"=>{
            let cfg=config::Config::load(Path::new(path))?;
            println!("{}",serde_json::json!({"configuration_valid":true,"mode":"inspect","live_enabled":false,
                "addresses_configured":cfg.program_id.is_some() && cfg.payer_public_key.is_some(),
                "budget_lamports":cfg.limits.max_total_exposure_lamports}));Ok(())
        },
        [flag,path,request,ledger_path] if flag=="--assess"=>{
            let cfg=config::Config::load(Path::new(path))?;
            let req:config::Request=serde_json::from_str(&config::bounded_text(Path::new(request),16_384)?)
                .map_err(|_|"Demande invalide".to_string())?;
            let reserved=ledger::reserve(Path::new(ledger_path),&cfg,&req)?;
            println!("{}",serde_json::json!({"reserved_exposure_lamports":reserved.exposure(),"signed":false,"sent":false,"live_enabled":false}));Ok(())
        },
        _=>Err("Transactions reelles verrouillees. Modes disponibles: --check-config FICHIER ou --assess CONFIG DEMANDE JOURNAL. Aucun portefeuille n'est charge.".into())
    }
}
fn main() {
    let args=std::env::args().skip(1).collect::<Vec<_>>();
    if let Err(error)=run(&args) {eprintln!("ARRET: {error}");std::process::exit(2);}
}
#[cfg(test)] mod tests {
    use super::*;
    #[test] fn startup_does_not_open_wallet_or_network() {assert!(run(&[]).is_err());}
    #[test] fn no_flag_or_environment_can_enable_live_mode() {for flag in ["--live","live","--send","--initialize"] {assert!(run(&[flag.into()]).is_err());}}
}
