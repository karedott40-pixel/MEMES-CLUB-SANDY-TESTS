use crate::{config::{bounded_text,Config,Request},guard::Budget};
use serde::{Serialize,Deserialize};
use solana_sdk::hash::hash;
use std::{fs::{self,File,OpenOptions},io::Write,path::{Path,PathBuf}};
#[cfg(unix)] use std::os::unix::fs::OpenOptionsExt;

#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
struct Record { schema:u32, config_fingerprint:String, attempts:u32, committed:u64, halted:bool, ids:Vec<String> }
#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
struct Envelope { record:Record, checksum:String }
struct Lock { path:PathBuf, _file:File }
impl Drop for Lock { fn drop(&mut self) { let _=fs::remove_file(&self.path); } }
fn suffix(path:&Path,suffix:&str)->PathBuf {let mut p=path.as_os_str().to_os_string();p.push(suffix);PathBuf::from(p)}
fn private_new(path:&Path)->Result<File,String> {
    let mut options=OpenOptions::new();options.write(true).create_new(true);
    #[cfg(unix)] options.mode(0o600);
    options.open(path).map_err(|_|"Ecriture exclusive impossible; essai refuse".to_string())
}
fn lock(path:&Path)->Result<Lock,String> {
    let parent=path.parent().filter(|p|!p.as_os_str().is_empty()).unwrap_or(Path::new("."));
    // Do not traverse existing symlink directories (including the ledger parent).
    for dir in parent.ancestors() {
        if !dir.as_os_str().is_empty() {
            let m=fs::symlink_metadata(dir).map_err(|_|"Dossier du journal inaccessible".to_string())?;
            if !m.is_dir() || m.file_type().is_symlink() {return Err("Dossier de journal non autorise".into());}
        }
    }
    let name=suffix(path,".lock");let mut file=private_new(&name)?;
    if file.write_all(b"Sandy exclusive lock; do not remove during a run\n").and_then(|_|file.sync_all()).is_err() {let _=fs::remove_file(&name);return Err("Verrou non durable".into());}
    Ok(Lock{path:name,_file:file})
}
fn stopped(path:&Path)->Result<bool,String> {
    match fs::symlink_metadata(suffix(path,".STOP")) { Ok(_)=>Ok(true),Err(e) if e.kind()==std::io::ErrorKind::NotFound=>Ok(false),Err(_)=>Err("Etat de l'arret d'urgence inaccessible".into()) }
}
fn save(path:&Path,record:Record)->Result<(),String> {
    let body=serde_json::to_vec(&record).map_err(|_|"Journal non serialisable".to_string())?;
    let env=Envelope{record,checksum:hash(&body).to_string()};
    let bytes=serde_json::to_vec(&env).map_err(|_|"Journal non serialisable".to_string())?;
    let temp=suffix(path,".pending");let mut file=private_new(&temp)?;
    file.write_all(&bytes).and_then(|_|file.sync_all()).map_err(|_|"Journal non durable; aucune autorisation".to_string())?;
    fs::rename(&temp,path).map_err(|_|"Validation atomique du journal impossible".to_string())?;
    let parent=path.parent().filter(|p|!p.as_os_str().is_empty()).unwrap_or(Path::new("."));
    File::open(parent).and_then(|f|f.sync_all()).map_err(|_|"Synchronisation du dossier impossible; aucune autorisation".to_string())?;
    Ok(())
}
pub struct Reservation { exposure:u64, principal:u64, fingerprint:String }
impl Reservation {
    pub fn exposure(&self)->u64 {self.exposure}
    pub fn principal(&self)->u64 {self.principal}
    pub fn matches(&self,cfg:&Config)->bool {cfg.fingerprint().ok().as_ref()==Some(&self.fingerprint)}
}
pub fn reserve(path:&Path,cfg:&Config,request:&Request)->Result<Reservation,String> {
    let cost=cfg.authorize_request(request)?;
    let _lock=lock(path)?;
    if stopped(path)? {return Err("Arret d'urgence actif".into());}
    let fingerprint=cfg.fingerprint()?;
    let mut record=match fs::symlink_metadata(path) {
        Err(e) if e.kind()==std::io::ErrorKind::NotFound=>Record{schema:2,config_fingerprint:fingerprint.clone(),attempts:0,committed:0,halted:false,ids:vec![]},
        Err(_)=>return Err("Etat du journal inconnu; essai refuse".into()),
        Ok(_)=>{
            let text=bounded_text(path,131_072)?;
            let envelope:Envelope=serde_json::from_str(&text).map_err(|_|"Journal corrompu; essai refuse".to_string())?;
            let raw=serde_json::to_vec(&envelope.record).map_err(|_|"Journal corrompu".to_string())?;
            if envelope.checksum!=hash(&raw).to_string() {return Err("Somme de controle du journal incorrecte".into());}
            envelope.record
        }
    };
    if record.schema!=2 || record.config_fingerprint!=fingerprint || record.ids.len()!=record.attempts as usize
        || record.ids.len()>1000 {return Err("Configuration modifiee ou journal incoherent; aucune remise a zero automatique".into());}
    if record.ids.iter().any(|id|id==&request.id) {return Err("Essai deja reserve; pas de nouvelle tentative automatique".into());}
    let mut budget=Budget{attempts:record.attempts,committed:record.committed,halted:record.halted};
    let exposure=budget.reserve(&cfg.limits.limits(),cost).map_err(|e|format!("Limite de risque: {e:?}"))?;
    record.attempts=budget.attempts;record.committed=budget.committed;record.halted=budget.halted;record.ids.push(request.id.clone());
    save(path,record)?;
    if stopped(path)? {return Err("Arret d'urgence actif; reservation conservee".into());}
    Ok(Reservation{exposure,principal:cost.principal,fingerprint})
}

#[cfg(test)]
mod tests {
    use super::*;use crate::config::tests::{config,request};
    struct Temp(PathBuf);impl Temp {fn new()->Self {let p=std::env::temp_dir().join(format!("sandy-risk-{}-{}",std::process::id(),solana_sdk::pubkey::Pubkey::new_unique()));fs::create_dir(&p).unwrap();Self(p)} fn ledger(&self)->PathBuf {self.0.join("risk.json")} }impl Drop for Temp {fn drop(&mut self){let _=fs::remove_dir_all(&self.0);}}
    #[test] fn restart_does_not_reset_spending() {let d=Temp::new();let c=config();let p=d.ledger();reserve(&p,&c,&request(&c,"one")).unwrap();reserve(&p,&c,&request(&c,"two")).unwrap();assert!(reserve(&p,&c,&request(&c,"three")).is_err());}
    #[test] fn repeated_id_cannot_charge_or_retry_twice() {let d=Temp::new();let c=config();let p=d.ledger();reserve(&p,&c,&request(&c,"one")).unwrap();let b=fs::read(&p).unwrap();assert!(reserve(&p,&c,&request(&c,"one")).is_err());assert_eq!(b,fs::read(p).unwrap());}
    #[test] fn unknown_outcome_keeps_full_reservation() {let d=Temp::new();let mut c=config();c.limits.max_total_exposure_lamports=110;let p=d.ledger();reserve(&p,&c,&request(&c,"timeout")).unwrap();assert!(reserve(&p,&c,&request(&c,"retry")).is_err());}
    #[test] fn changing_limits_cannot_reset_ledger() {let d=Temp::new();let mut c=config();let p=d.ledger();reserve(&p,&c,&request(&c,"one")).unwrap();c.limits.max_total_exposure_lamports=1000;assert!(reserve(&p,&c,&request(&c,"two")).is_err());}
    #[test] fn kill_switch_blocks_new_reservations() {let d=Temp::new();let c=config();let p=d.ledger();File::create(suffix(&p,".STOP")).unwrap();assert!(reserve(&p,&c,&request(&c,"one")).is_err());assert!(!p.exists());}
    #[test] fn stale_lock_and_interrupted_write_fail_closed() {for ending in [".lock",".pending"] {let d=Temp::new();let c=config();let p=d.ledger();File::create(suffix(&p,ending)).unwrap();assert!(reserve(&p,&c,&request(&c,"one")).is_err());}}
    #[test] fn corrupt_ledger_is_never_silently_reset() {let d=Temp::new();let c=config();let p=d.ledger();fs::write(&p,b"{bad").unwrap();assert!(reserve(&p,&c,&request(&c,"one")).is_err());assert_eq!(fs::read(p).unwrap(),b"{bad");}
    #[test] fn tampered_counter_without_checksum_is_rejected() {let d=Temp::new();let c=config();let p=d.ledger();reserve(&p,&c,&request(&c,"one")).unwrap();let mut v:serde_json::Value=serde_json::from_slice(&fs::read(&p).unwrap()).unwrap();v["record"]["committed"]=serde_json::json!(0);fs::write(&p,serde_json::to_vec(&v).unwrap()).unwrap();assert!(reserve(&p,&c,&request(&c,"two")).is_err());}
    #[cfg(unix)] #[test] fn symlink_ledger_and_parent_rejected() {use std::os::unix::fs::symlink;let d=Temp::new();let c=config();let p=d.ledger();let real=d.0.join("real");fs::write(&real,b"sentinel").unwrap();symlink(&real,&p).unwrap();assert!(reserve(&p,&c,&request(&c,"one")).is_err());assert_eq!(fs::read(&real).unwrap(),b"sentinel");fs::remove_file(&p).unwrap();fs::create_dir(d.0.join("dir")).unwrap();symlink(d.0.join("dir"),d.0.join("alias")).unwrap();assert!(reserve(&d.0.join("alias/risk.json"),&c,&request(&c,"one")).is_err());}
    #[test] fn concurrent_attempts_cannot_overspend() {use std::sync::{Arc,Barrier};let d=Temp::new();let mut c=config();c.limits.max_total_exposure_lamports=110;let c=Arc::new(c);let barrier=Arc::new(Barrier::new(3));let mut handles=vec![];for id in ["one","two"] {let c=c.clone();let b=barrier.clone();let p=d.ledger();handles.push(std::thread::spawn(move||{b.wait();reserve(&p,&c,&request(&c,id)).is_ok()}));}barrier.wait();assert_eq!(handles.into_iter().map(|h|h.join().unwrap()).filter(|v|*v).count(),1);}
    #[cfg(unix)] #[test] fn journal_is_private() {use std::os::unix::fs::PermissionsExt;let d=Temp::new();let c=config();let p=d.ledger();reserve(&p,&c,&request(&c,"one")).unwrap();assert_eq!(fs::metadata(p).unwrap().permissions().mode() & 0o777,0o600);}
}
