use borsh::{BorshDeserialize, BorshSerialize};
use crate::guard::Limits;
pub const MAGIC: &[u8;4] = b"SNY2";

#[derive(BorshSerialize, BorshDeserialize, Clone)]
pub struct Initialize {
    pub limits: Limits,
    pub tip_lamports: u64,
    pub tip_receiver: [u8;32],
    pub minimum_profit_lamports: u64,
}
#[derive(BorshSerialize, BorshDeserialize, Clone)]
pub struct SwapIn {
    pub user_amount_in: u64,
    pub user_minimum_amount_out: u64,
    pub max_input_lamports: u64,
    pub minimum_front_output: u64,
}

/// Explicit authority-signed recovery instruction; no live CLI enables it.
#[derive(BorshSerialize, BorshDeserialize, Clone)]
pub struct EmergencyExit {
    /// Maximum loss including the configured conservative fee ceiling.
    pub maximum_loss_lamports: u64,
    /// Positive minimum WSOL received from the recorded purchased amount only.
    pub minimum_output_lamports: u64,
}

pub fn encode<T: BorshSerialize>(tag:u8,args:&T)->Result<Vec<u8>,std::io::Error> {
    let mut data=MAGIC.to_vec(); data.push(tag); data.extend(borsh::to_vec(args)?); Ok(data)
}
