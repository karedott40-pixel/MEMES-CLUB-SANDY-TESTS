//! Conservative exposure budget, not an estimate of realized PnL.
use borsh::{BorshDeserialize, BorshSerialize};

#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct Limits {
    pub max_trade_lamports: u64,
    pub max_total_exposure_lamports: u64,
    pub max_network_fees_lamports: u64,
    pub max_tip_lamports: u64,
    pub max_account_cost_lamports: u64,
    pub max_attempts: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub struct Budget {
    pub attempts: u32,
    pub committed: u64,
    pub halted: bool,
}

impl Default for Budget {
    fn default() -> Self { Self { attempts: 0, committed: 0, halted: false } }
}

#[derive(Clone, Copy, Debug)]
pub struct Cost {
    pub principal: u64,
    /// Fees for ALL transactions/wallets included in this controlled attempt.
    pub network_fees: u64,
    pub tip: u64,
    pub account_cost: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Rejection { Disabled, Halted, TradeCap, FeeCap, TipCap, AccountCap, TotalCap,
    AttemptsCap, Overflow, InvalidBudget, InvalidLimits }

impl Limits {
    pub fn validate(&self) -> Result<(), Rejection> {
        if self.max_attempts > 1000 { return Err(Rejection::InvalidLimits); }
        // All-zero limits are a valid, intentionally locked configuration.
        if self.max_trade_lamports > self.max_total_exposure_lamports {
            return Err(Rejection::InvalidLimits);
        }
        Ok(())
    }
}

impl Cost {
    pub fn overhead(&self) -> Result<u64, Rejection> {
        self.network_fees.checked_add(self.tip).and_then(|v| v.checked_add(self.account_cost))
            .ok_or(Rejection::Overflow)
    }
    pub fn worst_case(&self) -> Result<u64, Rejection> {
        self.principal.checked_add(self.overhead()?).ok_or(Rejection::Overflow)
    }
}

impl Budget {
    pub fn reserve(&mut self, limits: &Limits, cost: Cost) -> Result<u64, Rejection> {
        limits.validate()?;
        if self.halted { return Err(Rejection::Halted); }
        if self.attempts > limits.max_attempts || self.committed > limits.max_total_exposure_lamports {
            return Err(Rejection::InvalidBudget);
        }
        if limits.max_trade_lamports == 0 || limits.max_total_exposure_lamports == 0
            || limits.max_attempts == 0 { return Err(Rejection::Disabled); }
        if self.attempts >= limits.max_attempts { return Err(Rejection::AttemptsCap); }
        if cost.principal == 0 || cost.principal > limits.max_trade_lamports { return Err(Rejection::TradeCap); }
        if cost.network_fees == 0 || cost.network_fees > limits.max_network_fees_lamports { return Err(Rejection::FeeCap); }
        if cost.tip > limits.max_tip_lamports { return Err(Rejection::TipCap); }
        if cost.account_cost > limits.max_account_cost_lamports { return Err(Rejection::AccountCap); }
        let exposure = cost.worst_case()?;
        let committed = self.committed.checked_add(exposure).ok_or(Rejection::Overflow)?;
        if committed > limits.max_total_exposure_lamports { return Err(Rejection::TotalCap); }
        let attempts = self.attempts.checked_add(1).ok_or(Rejection::Overflow)?;
        self.attempts = attempts;
        self.committed = committed;
        // Never release a reservation after a timeout, retry, restart or claimed profit.
        Ok(exposure)
    }
}

pub fn minimum_recovery(principal_spent: u64, overhead: u64, minimum_profit: u64) -> Result<u64, Rejection> {
    principal_spent.checked_add(overhead).and_then(|v| v.checked_add(minimum_profit))
        .filter(|v| *v > 0).ok_or(Rejection::Overflow)
}

pub fn emergency_exit_floor(principal_spent:u64, overhead:u64, maximum_loss:u64)->Result<u64,Rejection> {
    if principal_spent==0 {return Err(Rejection::InvalidLimits);}
    principal_spent.checked_add(overhead).and_then(|total|total.checked_sub(maximum_loss))
        .filter(|floor|*floor>0).ok_or(Rejection::InvalidLimits)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn limits() -> Limits { Limits { max_trade_lamports:100, max_total_exposure_lamports:240,
        max_network_fees_lamports:10, max_tip_lamports:5, max_account_cost_lamports:5, max_attempts:2 } }
    fn cost() -> Cost { Cost { principal:100, network_fees:10, tip:5, account_cost:5 } }
    #[test] fn all_wallet_costs_are_reserved() { let mut b=Budget::default(); assert_eq!(b.reserve(&limits(),cost()),Ok(120)); assert_eq!(b.committed,120); }
    #[test] fn exact_total_boundary_is_allowed_once_more() { let mut b=Budget::default(); b.reserve(&limits(),cost()).unwrap(); b.reserve(&limits(),cost()).unwrap(); assert_eq!(b.committed,240); assert!(b.reserve(&limits(),cost()).is_err()); }
    #[test] fn total_budget_blocks_smaller_extra_trade() { let mut b=Budget::default(); b.reserve(&limits(),cost()).unwrap(); let mut l=limits(); l.max_attempts=10; l.max_total_exposure_lamports=239; assert_eq!(b.reserve(&l,cost()),Err(Rejection::TotalCap)); assert_eq!(b.attempts,1); }
    #[test] fn individual_caps_are_enforced() { for (c,e) in [(Cost{principal:101,..cost()},Rejection::TradeCap),(Cost{network_fees:11,..cost()},Rejection::FeeCap),(Cost{tip:6,..cost()},Rejection::TipCap),(Cost{account_cost:6,..cost()},Rejection::AccountCap)] { assert_eq!(Budget::default().reserve(&limits(),c),Err(e)); } }
    #[test] fn rejected_request_does_not_mutate_budget() { let mut b=Budget::default(); assert!(b.reserve(&limits(),Cost{principal:101,..cost()}).is_err()); assert_eq!(b,Budget::default()); }
    #[test] fn zero_principal_and_zero_fee_rejected() { for c in [Cost{principal:0,..cost()},Cost{network_fees:0,..cost()}] { assert!(Budget::default().reserve(&limits(),c).is_err()); } }
    #[test] fn zero_budget_cannot_be_enabled_by_a_request() { let mut l=limits(); l.max_trade_lamports=0; assert_eq!(Budget::default().reserve(&l,cost()),Err(Rejection::Disabled)); }
    #[test] fn pause_is_sticky() { let mut b=Budget{halted:true,..Budget::default()}; assert_eq!(b.reserve(&limits(),cost()),Err(Rejection::Halted)); assert!(b.halted); }
    #[test] fn corrupted_counter_is_rejected() { let mut b=Budget{attempts:3,..Budget::default()}; assert_eq!(b.reserve(&limits(),cost()),Err(Rejection::InvalidBudget)); }
    #[test] fn overflow_cannot_wrap_budget() { let l=Limits{max_trade_lamports:u64::MAX,max_total_exposure_lamports:u64::MAX,max_network_fees_lamports:10,max_tip_lamports:5,max_account_cost_lamports:5,max_attempts:2}; assert_eq!(Budget::default().reserve(&l,Cost{principal:u64::MAX,..cost()}),Err(Rejection::Overflow)); }
    #[test] fn overhead_and_profit_are_included_in_exit_floor() { assert_eq!(minimum_recovery(100,20,3),Ok(123)); assert_eq!(minimum_recovery(u64::MAX,1,0),Err(Rejection::Overflow)); }
    #[test] fn unsafe_limits_rejected() { let mut l=limits(); l.max_total_exposure_lamports=99; assert!(l.validate().is_err()); l=limits(); l.max_attempts=1001; assert!(l.validate().is_err()); }
    #[test] fn emergency_floor_includes_fees_and_declared_loss() {assert_eq!(emergency_exit_floor(100,20,10),Ok(110));assert_eq!(emergency_exit_floor(100,20,100),Ok(20));assert_eq!(emergency_exit_floor(100,20,0),Ok(120));}
    #[test] fn emergency_loss_cannot_exceed_reserved_exposure_or_wrap() {for (p,f,l) in [(100,20,120),(100,20,121),(0,20,1),(u64::MAX,1,0)] {assert!(emergency_exit_floor(p,f,l).is_err());}}
}
