use borsh::BorshDeserialize;
use solana_program::program_error::ProgramError;
pub use crate::protocol::{Initialize,SwapIn,EmergencyExit};
pub enum SandyInstruction { Initialize(Initialize),SwapIn(SwapIn),SwapOut,Pause,EmergencyExit(EmergencyExit) }
impl SandyInstruction {
    pub fn unpack(data:&[u8])->Result<Self,ProgramError> {
        if data.get(..4)!=Some(crate::protocol::MAGIC.as_slice()) {return Err(ProgramError::InvalidInstructionData);}
        let (&tag,rest)=data[4..].split_first().ok_or(ProgramError::InvalidInstructionData)?;
        Ok(match tag {
            0=>Self::Initialize(Initialize::try_from_slice(rest)?),
            1=>Self::SwapIn(SwapIn::try_from_slice(rest)?),
            2 if rest.is_empty()=>Self::SwapOut,
            3 if rest.is_empty()=>Self::Pause,
            4=>Self::EmergencyExit(EmergencyExit::try_from_slice(rest)?),
            _=>return Err(ProgramError::InvalidInstructionData),
        })
    }
}
#[cfg(test)] mod tests {
    use super::*;
    #[test] fn legacy_or_trailing_payload_cannot_bypass_limits() {for data in [vec![],vec![0;11],vec![1;17],b"SNY2\x02extra".to_vec(),b"SNY2\x09".to_vec()] {assert!(SandyInstruction::unpack(&data).is_err());}}
    #[test] fn new_protocol_round_trip() {let a=SwapIn{user_amount_in:1,user_minimum_amount_out:1,max_input_lamports:2,minimum_front_output:1};let data=crate::protocol::encode(1,&a).unwrap();assert!(matches!(SandyInstruction::unpack(&data),Ok(SandyInstruction::SwapIn(_))));}
    #[test] fn emergency_payload_is_strict_and_separate_from_normal_exit() {let a=EmergencyExit{maximum_loss_lamports:10,minimum_output_lamports:90};let mut d=crate::protocol::encode(4,&a).unwrap();assert!(matches!(SandyInstruction::unpack(&d),Ok(SandyInstruction::EmergencyExit(_))));d.push(0);assert!(SandyInstruction::unpack(&d).is_err());assert!(SandyInstruction::unpack(b"SNY2\x04").is_err());}
}
