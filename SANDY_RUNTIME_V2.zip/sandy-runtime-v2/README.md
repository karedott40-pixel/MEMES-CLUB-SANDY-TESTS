# Local runtime verification V2

Only a fresh loopback Solana chain in an isolated CI network namespace. All keys generated in memory; every balance is fictitious. No live bot or public cluster transmission.

Builds Sandy Safety V3 and official historical Raydium AMM v4 at d8e88250a648cff370d588acb91db7c4ff72b52b, verifies every official source blob before compilation, and executes SwapOnly swaps with synthetic reserves. Raydium is built with platform tools v1.37, matching Solana 1.16.24; Sandy uses v1.42. Any stack-limit diagnostic still fails the build.

Tests normal buy / controlled owned-wallet swap / sell, fee charging on a failed sell, atomic rollback, authority checks, existing token preservation, permanent reservations, and an explicit bounded emergency exit after pause.

The controlled target has its own 100 fictitious SOL capital reservation. The bot uses at most 1 fictitious SOL per case, plus declared fee and tip ceilings. Target costs and bot results are distinct; the synthetic favorable cycle is not economic profit for the combined owner. Emergency loss cap is 0.01 fictitious SOL including all scenario network fees, with no extra tip. Fixed initialization rent and fees are reported separately.

A green workflow means the scoped checks completed. It does not verify mainnet equivalence, live data, market ordering, Jito bundle atomicity, production fee enforcement, liquidity availability, or profitability. Production CLI and relayer stay disabled.
