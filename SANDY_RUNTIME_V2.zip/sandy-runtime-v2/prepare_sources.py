"""Extract reviewed test sources; freeze official Raydium files by their Git blob IDs."""
from pathlib import Path, PurePosixPath
import hashlib,json,os,stat,tarfile,zipfile

SANDY_SHA='85a427a40aa16083145a122fa8075a6c4c8bd947c2bd308b9105e91b4f98d5b9'
def extract_sandy():
    p=Path('SANDY_SAFETY_V3.zip')
    assert hashlib.sha256(p.read_bytes()).hexdigest()==SANDY_SHA,'Sandy archive changed'
    with zipfile.ZipFile(p) as z:
        for entry in z.infolist():
            q=PurePosixPath(entry.filename)
            assert not q.is_absolute() and '..' not in q.parts and q.parts[0]=='sandy-safety-v3'
            assert not stat.S_ISLNK(entry.external_attr>>16) and entry.file_size<2_000_000
        z.extractall('.')
    for row in Path('sandy-safety-v3/SOURCE_SHA256SUMS').read_text().splitlines():
        digest,name=row.split('  ',1)
        assert hashlib.sha256(Path('sandy-safety-v3',name).read_bytes()).hexdigest()==digest
    target=Path('sandy-safety-v3/bot/src/bin/runtime_checks.rs')
    assert not target.exists()
    target.parent.mkdir()
    target.write_bytes(Path('sandy-runtime-v2/runtime_checks.rs').read_bytes())

def extract_raydium():
    archive=Path(os.environ['RUNNER_TEMP'],'raydium.tar.gz')
    dest=Path(os.environ['RUNNER_TEMP'],'raydium-source');dest.mkdir()
    print('RAYDIUM_ARCHIVE_SHA256='+hashlib.sha256(archive.read_bytes()).hexdigest())
    tree=json.loads(Path('sandy-runtime-v2/provenance/raydium_git_tree.json').read_text())
    expected={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    seen=set()
    with tarfile.open(archive) as handle:
        for member in handle:
            parts=PurePosixPath(member.name).parts
            assert not PurePosixPath(member.name).is_absolute() and '..' not in parts
            if member.isdir():continue
            assert member.isfile() and member.size<2_000_000
            name='/'.join(parts[1:]);assert name in expected and name not in seen
            data=handle.extractfile(member).read()
            blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            assert blob==expected[name]['sha'],'Official source blob mismatch: '+name
            p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);seen.add(name)
    assert seen==set(expected),'Missing official source files'
    print('RAYDIUM_OFFICIAL_SOURCE_FILES_VERIFIED='+str(len(seen)))

if __name__=='__main__':
    extract_sandy();extract_raydium()
